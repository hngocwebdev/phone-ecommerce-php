@if(session('logged_in') && session('role') === 'admin')
    @include('admin.template.header_admin')
@else
    @include('admin.template.header')
@endif

<style>
/* ========== ANIMATION ========== */
@keyframes rise {
    from { opacity: 0; transform: translateY(50px) scale(.96); }
    to { opacity: 1; transform: translateY(0) scale(1); }
}

@keyframes glowMove {
    from { background-position: 0% 50%; }
    to { background-position: 200% 50%; }
}

/* ========== MAIN CARD ========== */
.confirm-wrapper {
    max-width: 1000px;
    margin: 70px auto;
    padding: 50px;
    border-radius: 30px;
    background:
        linear-gradient(135deg,#1b1f63,#6a11cb);
    box-shadow: 0 50px 120px rgba(0,0,0,.6);
    color: #fff;
    animation: rise .9s ease forwards;
    position: relative;
    overflow: hidden;
}

/* moving light */
.confirm-wrapper::before {
    content: "";
    position: absolute;
    inset: -60%;
    background: linear-gradient(
        120deg,
        transparent,
        rgba(255,255,255,.18),
        transparent
    );
    animation: glowMove 12s linear infinite;
    pointer-events: none;
}

/* ========== TITLE ========== */
.confirm-title {
    font-size: 38px;
    font-weight: 900;
    text-align: center;
    color: #2cff9a;
    margin-bottom: 35px;
    letter-spacing: .6px;
}

/* ========== INFO GRID ========== */
.confirm-info {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 20px;
    margin-bottom: 40px;
}

.confirm-info div {
    background: rgba(255,255,255,.1);
    border-radius: 18px;
    padding: 18px 20px;
    font-size: 15px;
}

.confirm-info strong {
    display: block;
    font-size: 13px;
    opacity: .8;
    margin-bottom: 4px;
}

/* ========== TABLE ========== */
.confirm-table {
    border-radius: 22px;
    overflow: hidden;
    margin-bottom: 30px;
}

.confirm-table thead {
    background: linear-gradient(135deg,#ffd54f,#ff9800);
    color: #111;
}

.confirm-table th,
.confirm-table td {
    padding: 16px;
    vertical-align: middle;
}

.confirm-table tbody tr {
    background: rgba(255,255,255,.06);
    transition: .25s;
}

.confirm-table tbody tr:hover {
    background: rgba(255,255,255,.15);
}

/* ========== TOTAL BOX ========== */
.confirm-total-box {
    background: linear-gradient(135deg,#ffd54f,#ff9800);
    color: #111;
    border-radius: 22px;
    padding: 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: 900;
    font-size: 22px;
    margin-bottom: 35px;
}

/* ========== BUTTON ========== */
.confirm-btn {
    width: 100%;
    padding: 20px;
    font-size: 20px;
    font-weight: 900;
    border-radius: 22px;
    border: none;
    background: linear-gradient(135deg,#2cff9a,#00e676);
    color: #003;
    cursor: pointer;
    transition: .35s;
}

.confirm-btn:hover {
    transform: translateY(-4px);
    box-shadow: 0 25px 50px rgba(0,0,0,.45);
}

.confirm-btn:active {
    transform: scale(.97);
}

/* ========== MOBILE ========== */
@media (max-width: 768px) {
    .confirm-wrapper {
        padding: 28px;
        margin: 30px 15px;
    }

    .confirm-title {
        font-size: 28px;
    }

    .confirm-info {
        grid-template-columns: 1fr;
    }

    .confirm-total-box {
        font-size: 18px;
    }
}
</style>

<div class="confirm-wrapper">

    <div class="confirm-title">
        🧾 Xác nhận đơn hàng
    </div>

    {{-- THÔNG TIN KHÁCH --}}
    <div class="confirm-info">
        <div>
            <strong>Họ tên</strong>
            {{ $fullname }}
        </div>
        <div>
            <strong>Số điện thoại</strong>
            {{ $phone }}
        </div>
        <div>
            <strong>Địa chỉ</strong>
            {{ $address }}
        </div>
    </div>

    {{-- SẢN PHẨM --}}
    <div class="table-responsive confirm-table">
        <table class="table text-white mb-0">
            <thead>
                <tr>
                    <th>Sản phẩm</th>
                    <th class="text-center">Số lượng</th>
                    <th class="text-end">Giá</th>
                    <th class="text-end">Tổng</th>
                </tr>
            </thead>
            <tbody>
                @php $sumTotal = 0; @endphp
                @foreach($cartItems as $item)
                    @php
                        $sum = $item->price * $item->qty;
                        $sumTotal += $sum;
                    @endphp
                    <tr>
                        <td>{{ $item->product_name }}</td>
                        <td class="text-center">{{ $item->qty }}</td>
                        <td class="text-end">{{ number_format($item->price) }} đ</td>
                        <td class="text-end">{{ number_format($sum) }} đ</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    {{-- TOTAL --}}
    <div class="confirm-total-box">
        <span>Tổng thanh toán</span>
        <span>{{ number_format($sumTotal) }} đ</span>
    </div>

    {{-- BUTTON --}}
    <form action="{{ url('/checkout/done') }}" method="POST">
        @csrf
        <input type="hidden" name="fullname" value="{{ $fullname }}">
        <input type="hidden" name="phone" value="{{ $phone }}">
        <input type="hidden" name="address" value="{{ $address }}">

        <button type="submit" class="confirm-btn">
            🚀 Xác nhận đặt hàng
        </button>
    </form>

</div>

@include('admin.template.footer')
