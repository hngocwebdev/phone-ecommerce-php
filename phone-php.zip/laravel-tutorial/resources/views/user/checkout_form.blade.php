@if(session('logged_in') && session('role') === 'admin')
    @include('admin.template.header_admin')
@else
    @include('admin.template.header')
@endif

<style>
/* ================= RESET ================= */
* { box-sizing: border-box; }

/* ================= ANIMATION ================= */
@keyframes fadeUp {
    from { opacity: 0; transform: translateY(40px) scale(.96); }
    to   { opacity: 1; transform: translateY(0) scale(1); }
}

@keyframes glow {
    0% { box-shadow: 0 0 0 rgba(44,255,154,0); }
    50% { box-shadow: 0 0 25px rgba(44,255,154,.35); }
    100% { box-shadow: 0 0 0 rgba(44,255,154,0); }
}

/* ================= WRAPPER ================= */
.checkout-wrapper {
    max-width: 720px;
    margin: 70px auto;
    padding: 48px;
    border-radius: 28px;
    background: linear-gradient(135deg, #1b1f63, #6a11cb);
    box-shadow: 0 45px 100px rgba(0,0,0,.55);
    animation: fadeUp .9s ease forwards;
    position: relative;
    overflow: hidden;
}

/* ánh sáng nền */
.checkout-wrapper::before {
    content: "";
    position: absolute;
    inset: -50%;
    background: radial-gradient(circle, rgba(255,255,255,.18), transparent 60%);
    animation: spin 18s linear infinite;
    pointer-events: none;
}

@keyframes spin {
    from { transform: rotate(0); }
    to   { transform: rotate(360deg); }
}

/* ================= TITLE ================= */
.checkout-title {
    font-size: 36px;
    font-weight: 900;
    text-align: center;
    color: #2cff9a;
    margin-bottom: 38px;
    letter-spacing: .6px;
    animation: fadeUp 1.1s ease forwards;
}

/* ================= LABEL ================= */
.checkout-wrapper label {
    display: block;
    font-weight: 700;
    font-size: 14.5px;
    color: rgba(255,255,255,.95);
    margin-bottom: 6px;
}

/* ================= INPUT ================= */
.checkout-wrapper .form-control {
    width: 100%;
    padding: 15px 18px;
    border-radius: 16px;
    border: none;
    font-size: 16px;
    background: rgba(255,255,255,.96);
    transition: .35s;
    box-shadow: inset 0 0 0 2px rgba(255,255,255,.25);
}

/* focus = động */
.checkout-wrapper .form-control:focus {
    transform: translateY(-3px) scale(1.01);
    box-shadow:
        0 14px 30px rgba(0,0,0,.4),
        inset 0 0 0 2px rgba(44,255,154,.85);
    animation: glow 1.4s ease;
    outline: none;
}

/* textarea */
.checkout-wrapper textarea {
    resize: none;
}

/* ================= FORM GROUP ================= */
.checkout-wrapper .mb-3,
.checkout-wrapper .mb-4 {
    animation: fadeUp 1.2s ease forwards;
}

/* ================= BUTTON ================= */
.checkout-btn {
    width: 100%;
    padding: 18px;
    font-size: 19px;
    font-weight: 900;
    border-radius: 20px;
    border: none;
    background: linear-gradient(135deg,#ffd54f,#ff9800);
    color: #111;
    cursor: pointer;
    transition: .35s;
    position: relative;
    overflow: hidden;
}

/* hover */
.checkout-btn:hover {
    transform: translateY(-4px) scale(1.01);
    box-shadow: 0 25px 45px rgba(0,0,0,.45);
}

/* click */
.checkout-btn:active {
    transform: scale(.96);
}

/* sóng sáng */
.checkout-btn::after {
    content: "";
    position: absolute;
    inset: 0;
    background: radial-gradient(circle, rgba(255,255,255,.55), transparent 70%);
    opacity: 0;
    transition: .3s;
}

.checkout-btn:hover::after {
    opacity: .45;
}

/* ================= MOBILE ================= */
@media (max-width: 576px) {
    .checkout-wrapper {
        padding: 30px;
        margin: 30px 16px;
        border-radius: 22px;
    }

    .checkout-title {
        font-size: 28px;
    }

    .checkout-btn {
        font-size: 17px;
    }
}
</style>

<div class="checkout-wrapper text-white">

    <div class="checkout-title">
        🚚 Thông tin giao hàng
    </div>

    <form action="{{ url('/checkout/confirm') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label>Họ và tên</label>
            <input type="text" name="fullname" class="form-control"
                   value="{{ old('fullname', $lastOrder->fullname ?? '') }}" required>
        </div>

        <div class="mb-3">
            <label>Số điện thoại</label>
            <input type="text" name="phone" class="form-control"
                   value="{{ old('phone', $lastOrder->phone ?? '') }}" required>
        </div>

        <div class="mb-4">
            <label>Địa chỉ</label>
            <textarea name="address" class="form-control" rows="3" required>
{{ old('address', $lastOrder->address ?? '') }}</textarea>
        </div>

        <button type="submit" class="checkout-btn">
            ➜ Tiếp tục đặt hàng
        </button>
    </form>

</div>

@include('admin.template.footer')
