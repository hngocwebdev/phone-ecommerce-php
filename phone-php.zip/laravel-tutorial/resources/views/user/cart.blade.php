@if(session('logged_in') && session('role') === 'admin')
    @include('admin.template.header_admin')
@else
    @include('admin.template.header')
@endif
<style>
    /* Bảng giỏ hàng */
    table.table {
        background: rgba(255,255,255,0.12);
        border-radius: 10px;
        overflow: hidden;
    }

    table th, table td {
        vertical-align: middle !important;
        text-align: center;
    }

    table th {
        font-weight: 700;
        font-size: 15px;
    }

    table td {
        font-size: 15px;
    }

    /* Ảnh sản phẩm */
    table img {
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.25);
    }

    /* Input số lượng */
    .qty-input {
        max-width: 90px;
        text-align: center;
        font-weight: 600;
    }

    /* Thành tiền */
    .item-sum {
        font-weight: 700;
        color: #ffd54f;
    }

    /* Tổng cộng */
    #cart-total {
        font-size: 18px;
        font-weight: 800;
        color: #2cff9a;
    }

    /* Nhóm nút hành động */
    .cart-actions {
        display: flex;
        justify-content: flex-end; /* 👉 ĐẨY QUA PHẢI */
        gap: 12px;
        margin-top: 20px;
    }

    .cart-actions .btn {
        padding: 10px 22px;
        font-weight: 700;
        border-radius: 8px;
    }

    .btn-success {
        background: linear-gradient(135deg, #2ecc71, #27ae60);
        border: none;
    }

    .btn-warning {
        background: linear-gradient(135deg, #ffc107, #ff9800);
        border: none;
        color: #000;
    }

    .btn-warning:hover {
        color: #000;
    }
    /* =======================
   CARD + TABLE ANIMATION
    ======================= */
    .table {
        background: rgba(255,255,255,0.12);
        border-radius: 14px;
        overflow: hidden;
        animation: fadeUp 0.6s ease;
    }

    @keyframes fadeUp {
        from {
            opacity: 0;
            transform: translateY(25px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* =======================
    ROW HOVER EFFECT
    ======================= */
    .table tbody tr {
        transition: 0.3s ease;
    }

    .table tbody tr:hover {
        background: rgba(255,255,255,0.15);
        transform: scale(1.01);
    }

    /* =======================
    PRODUCT IMAGE EFFECT
    ======================= */
    .table img {
        border-radius: 10px;
        transition: 0.3s ease;
    }

    .table tbody tr:hover img {
        transform: scale(1.08) rotate(-1deg);
    }

    /* =======================
    PRICE & TOTAL EFFECT
    ======================= */
    .item-sum {
        font-weight: 800;
        color: #ffd54f;
        transition: 0.3s;
    }

    .item-price {
        font-weight: 600;
    }

    /* flash khi giá đổi */
    .price-flash {
        animation: flash 0.4s ease;
    }

    @keyframes flash {
        0% { color: #fff; }
        50% { color: #2cff9a; }
        100% { color: #ffd54f; }
    }

    /* =======================
    QTY INPUT EFFECT
    ======================= */
    .qty-input {
        max-width: 90px;
        text-align: center;
        font-weight: 700;
        transition: 0.25s ease;
    }

    .qty-input:focus {
        transform: scale(1.08);
        box-shadow: 0 0 0 3px rgba(44,255,154,0.5);
    }

    /* =======================
    TOTAL BOX EFFECT
    ======================= */
    #cart-total {
        font-size: 20px;
        font-weight: 900;
        color: #2cff9a;
        transition: 0.3s;
    }

    /* =======================
    ACTION BUTTONS
    ======================= */
    .cart-actions {
        display: flex;
        justify-content: flex-end;
        gap: 14px;
        margin-top: 25px;
    }

    .cart-actions .btn {
        padding: 12px 26px;
        font-weight: 800;
        border-radius: 12px;
        transition: 0.3s ease;
    }

    .cart-actions .btn-success {
        background: linear-gradient(135deg, #2ecc71, #27ae60);
        border: none;
    }

    .cart-actions .btn-warning {
        background: linear-gradient(135deg, #ffc107, #ff9800);
        border: none;
        color: #000;
    }

    .cart-actions .btn:hover {
        transform: translateY(-4px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.35);
    }

</style>

<div class="container mt-4 text-white">
    <h2 class="mb-3">Giỏ hàng</h2>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if($cart->isEmpty())
        <p>Giỏ hàng trống</p>
    @else
    <form action="/cart/update" method="POST">
        @csrf

        <table class="table table-bordered text-white">
            <tr class="table-primary text-dark">
                <th>Ảnh</th>
                <th>Tên</th>
                <th>Giá</th>
                <th>Số lượng</th>
                <th>Thành tiền</th>
                <th></th>
            </tr>

            @php $total = 0; @endphp

            @foreach($cart as $item)
                @php
                    $sum = $item->price * $item->qty;
                    $total += $sum;
                @endphp
                <tr>
                    <td>
                        <img src="{{ $item->img }}" width="70">
                    </td>

                    <td>{{ $item->product_name }}</td>

                    <td class="item-price"
                        data-price="{{ $item->price }}">
                        {{ number_format($item->price) }} đ
                    </td>

                    <td>
                        <input type="number"
                               name="qty[{{ $item->cart_item_id }}]"
                               value="{{ $item->qty }}"
                               min="1"
                               class="form-control w-50 qty-input"
                               data-price="{{ $item->price }}">
                    </td>

                    <td class="item-sum">
                        {{ number_format($sum) }} đ
                    </td>

                    <td>
                        <a href="/cart/remove/{{ $item->cart_item_id }}"
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Xóa sản phẩm này?')">
                            Xóa
                        </a>
                    </td>
                </tr>
            @endforeach

            <tr>
                <th colspan="4" class="text-end">Tổng cộng:</th>
                <th id="cart-total">{{ number_format($total) }} đ</th>
                <th></th>
            </tr>
        </table>

        <div class="cart-actions">
            <button class="btn btn-success">
                🔄 Cập nhật giỏ hàng
            </button>

            <a href="/checkout" class="btn btn-warning">
                💳 Thanh toán
            </a>
        </div>

    </form>
    @endif
</div>

{{-- ================= JS TÍNH GIÁ REALTIME ================= --}}
<script>
document.querySelectorAll('.qty-input').forEach(input => {
    input.addEventListener('input', function () {
        let qty = parseInt(this.value);
        if (isNaN(qty) || qty < 1) {
            qty = 1;
            this.value = 1;
        }

        let price = parseInt(this.dataset.price);

        // Thành tiền từng dòng
        let row = this.closest('tr');
        let sumCell = row.querySelector('.item-sum');
        let sum = price * qty;
        sumCell.innerText = sum.toLocaleString('vi-VN') + ' đ';

        // hiệu ứng flash
        sumCell.classList.remove('price-flash');
        void sumCell.offsetWidth;
        sumCell.classList.add('price-flash');

        // Tổng cộng
        let total = 0;
        document.querySelectorAll('.qty-input').forEach(i => {
            let p = parseInt(i.dataset.price);
            let q = parseInt(i.value);
            if (isNaN(q) || q < 1) q = 1;
            total += p * q;
        });

        let totalEl = document.getElementById('cart-total');
        totalEl.innerText = total.toLocaleString('vi-VN') + ' đ';

        totalEl.classList.remove('price-flash');
        void totalEl.offsetWidth;
        totalEl.classList.add('price-flash');
    });
});
</script>


@include('admin.template.footer')
