@if(session('logged_in') && session('role') === 'admin')
    @include('admin.template.header_admin')
@else
    @include('admin.template.header')
@endif


<div class="container mt-5 text-white">

    <h2 class="mb-4">Kết quả tìm kiếm cho: <span class="text-warning">{{ $key }}</span></h2>

    @if(count($products) == 0)
        <p>Không tìm thấy sản phẩm nào.</p>
    @else
    <div class="row">
        @foreach($products as $p)
        <div class="col-md-3 mb-4">
            <div class="card shadow">

                <img src="{{ $p->product_img }}" class="card-img-top" style="height:200px;object-fit:contain;background:#fff;padding:10px;">

                <div class="card-body">
                    <h5>{{ $p->product_name }}</h5>
                    <p class="text-danger fw-bold">{{ number_format($p->product_price) }} đ</p>

                    <a href="/san-pham/{{ $p->product_id }}" class="btn btn-primary w-100 btn-sm">
                        Xem chi tiết
                    </a>
                </div>
            </div>
        </div>
        @endforeach
    </div>
    @endif

</div>

@include('admin.template.footer')
