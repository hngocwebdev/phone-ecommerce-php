@if(session('logged_in') && session('role') === 'admin')
    @include('admin.template.header_admin')
@else
    @include('admin.template.header')
@endif

<style>
    .form-container {
        max-width: 650px;
        margin: 40px auto;
        padding: 30px;
        background: #ffffff;
        border-radius: 14px;
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
        border: 1px solid #e3e3e3;
    }

    h2 {
        text-align: center;
        font-weight: 700;
        margin-bottom: 25px;
        color: #333;
    }

    .form-group {
        margin-bottom: 18px;
    }

    label {
        font-weight: 600;
        margin-bottom: 6px;
        display: block;
        color: #444;
    }

    input[type="text"] {
        width: 100%;
        padding: 12px;
        border-radius: 8px;
        border: 1px solid #ccc;
        font-size: 15px;
        background: #fafafa;
        transition: 0.2s;
    }

    input[type="text"]:focus {
        border-color: #4a8af4;
        box-shadow: 0 0 6px rgba(74, 138, 244, 0.3);
        background: #fff;
        outline: none;
    }

    input[type="submit"] {
        width: 100%;
        padding: 14px;
        background: #1a73e8;
        border: none;
        color: white;
        font-size: 16px;
        font-weight: 600;
        border-radius: 8px;
        cursor: pointer;
        transition: 0.3s;
        margin-top: 10px;
    }

    input[type="submit"]:hover {
        background: #0c56c3;
        transform: translateY(-2px);
    }
</style>

<div class="form-container">

    <h2>Thay đổi tài khoản người dùng</h2>

    <form action="{{ url('admin/xu-ly-cap-nhat-nguoi-dung') }}" method="post">
        @csrf

        @foreach ($users as $user)

        <div class="form-group">
            <label for="fname">Tên đăng nhập:</label>
            <input type="text" id="fname" name="username"
                value="{{ $user->user_username }}" required>
        </div>

        <div class="form-group">
            <label for="laddress">Địa chỉ:</label>
            <input type="text" id="laddress" name="address"
                value="{{ $user->user_address }}" required>
        </div>

        <div class="form-group">
            <label for="lfullname">Họ tên:</label>
            <input type="text" id="lfullname" name="fullname"
                value="{{ $user->user_fullname }}" required>
        </div>

        <input type="hidden" name="id" value="{{ $user->user_id }}">

        @endforeach

        <input type="submit" value="Cập nhật">
    </form>
</div>

@include('admin/template/footer')
