@if(session('logged_in') && session('role') === 'admin')
    @include('admin.template.header_admin')
@else
    @include('admin.template.header')
@endif


<style>
    body {
        margin: 0;
        padding: 60px 0;
        background: linear-gradient(135deg, #0f0f0f, #3a0ca3, #7209b7);
        font-family: "Segoe UI", sans-serif;
        color: white;
    }

    /* WRAPPER */
    .register-wrapper {
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    /* CARD GLASS */
    .register-card {
        width: 420px;
        padding: 40px 35px;
        border-radius: 18px;
        background: rgba(255,255,255,0.07);
        backdrop-filter: blur(10px);
        border: 1.8px solid rgba(255,255,255,0.18);
        box-shadow: 0 0 20px rgba(115,0,255,0.25);
        animation: fadeIn .35s ease;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* TITLE */
    .register-title {
        text-align: center;
        font-size: 26px;
        font-weight: 800;
        color: #ffffff;
        margin-bottom: 25px;
        letter-spacing: 1px;
    }

    .register-title i {
        font-size: 36px;
        color: #ffdd57;
        margin-bottom: 10px;
    }

    /* INPUT FIELD */
    .input-group {
        margin-bottom: 18px;
    }

    .input-label {
        font-weight: 600;
        margin-bottom: 6px;
        color: #eeeeee;
        display: block;
    }

    .input-box {
        width: 100%;
        padding: 12px;
        border-radius: 10px;
        border: 1.5px solid rgba(255,255,255,0.25);
        background: rgba(255,255,255,0.12);
        color: white;
        outline: none;
        font-size: 15px;
        transition: 0.25s;
    }

    .input-box:focus {
        border-color: #b57aff;
        background: rgba(255,255,255,0.2);
        box-shadow: 0 0 8px rgba(181,122,255,0.6);
    }

    /* BUTTON */
    .btn-register {
        width: 100%;
        padding: 12px;
        background: #ffdd57;
        border: none;
        border-radius: 10px;
        font-size: 17px;
        font-weight: 800;
        color: #000;
        cursor: pointer;
        transition: 0.25s;
    }

    .btn-register:hover {
        background: #ffe680;
        box-shadow: 0 0 12px rgba(255,221,87,0.8);
    }

    /* LOGIN LINK */
    .login-link {
        text-align: center;
        margin-top: 18px;
        font-size: 14px;
        color: #ddd;
    }

    .login-link a {
        color: #ffdd57;
        text-decoration: none;
        font-weight: 600;
    }

    .login-link a:hover {
        text-decoration: underline;
    }
</style>

<div class="register-wrapper">

    <div class="register-card">

        <div class="register-title">
            <i class="bi bi-person-plus-fill"></i><br>
             ĐĂNG NHẬP
        </div>

        <form action="{{ url('/admin/xu-ly-them-nguoi-dung') }}" method="POST">
            @csrf

            <div class="input-group">
                <label class="input-label">Tài khoản</label>
                <input type="text" name="username" class="input-box" required>
            </div>

            <div class="input-group">
                <label class="input-label">Mật khẩu</label>
                <input type="password" name="password" class="input-box" required>
            </div>

            <div class="input-group">
                <label class="input-label">Họ tên</label>
                <input type="text" name="fullname" class="input-box" required>
            </div>

            <div class="input-group">
                <label class="input-label">Địa chỉ</label>
                <input type="text" name="address" class="input-box" required>
            </div>

            <button class="btn-register">Đăng ký</button>
        </form>

        <div class="login-link">
            Đã có tài khoản?
            <a href="{{ url('admin/login') }}">Đăng nhập</a>
        </div>

    </div>

</div>

@include('admin/template/footer')
