@php
    use Illuminate\Support\Facades\DB;

    $cartCount = 0;

    if (session()->has('user_id')) {
        $cart = DB::table('carts')
            ->where('user_id', session('user_id'))
            ->first();

        if ($cart) {
            $cartCount = DB::table('cart_items')
                ->where('cart_id', $cart->cart_id)
                ->sum('qty');
        }
    }
@endphp


<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>TechZone</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background: linear-gradient(135deg, #0f0f0f, #3a0ca3, #7209b7);
      margin: 0;
      font-family: "Segoe UI", sans-serif;
    }

    /* =========================
   HEADER – PRO
========================= */
.tz-header {
    background: linear-gradient(135deg,#0a1a3a,#1a2b6d);
    padding: 18px 32px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    box-shadow:
        0 18px 45px rgba(0,0,0,.45),
        inset 0 0 0 1px rgba(255,255,255,.05);
    position: sticky;
    top: 0;
    z-index: 1000;
}

/* LOGO */
.tz-logo {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #ffd400;
    font-size: 30px;
    font-weight: 900;
    letter-spacing: 1.2px;
    text-transform: uppercase;
    transition: .3s;
}

.tz-logo:hover {
    transform: scale(1.05);
    text-shadow: 0 0 15px rgba(255,212,0,.7);
}

/* =========================
   SEARCH BOX
========================= */
.tz-search {
    flex: 1;
    max-width: 540px;
    position: relative;
    margin: 10px 30px;
}

.tz-search input {
    width: 100%;
    padding: 14px 50px 14px 18px;
    border-radius: 999px;
    border: none;
    outline: none;
    background: rgba(255,255,255,.95);
    font-size: 15px;
    transition: .35s;
    box-shadow: 0 6px 20px rgba(0,0,0,.25);
}

.tz-search input:focus {
    transform: scale(1.03);
    box-shadow: 0 0 0 3px rgba(255,212,0,.5),
                0 10px 30px rgba(0,0,0,.35);
}

#search-icon {
    position: absolute;
    right: 18px;
    top: 50%;
    transform: translateY(-50%);
    color: #333;
    font-size: 20px;
    cursor: pointer;
    transition: .25s;
}

#search-icon:hover {
    color: #ff9800;
    transform: translateY(-50%) scale(1.15);
}

/* =========================
   ACTION BUTTONS
========================= */
.tz-actions {
    display: flex;
    align-items: center;
    gap: 18px;
}

.tz-actions a,
.tz-city {
    text-decoration: none;
    color: #fff;
    font-weight: 700;
    padding: 10px 16px;
    border-radius: 999px;
    background: rgba(255,255,255,.08);
    backdrop-filter: blur(6px);
    display: flex;
    align-items: center;
    gap: 6px;
    transition: .3s;
}

.tz-actions a:hover,
.tz-city:hover {
    background: rgba(255,255,255,.18);
    transform: translateY(-2px);
}

/* =========================
   CART BADGE – DYNAMIC
========================= */
.tz-actions .badge {
    font-size: 12px;
    padding: 5px 8px;
    animation: pop .4s ease;
}

@keyframes pop {
    0% { transform: scale(.6); }
    100% { transform: scale(1); }
}

/* =========================
   NAVIGATION
========================= */
.tz-nav {
    background: rgba(255,255,255,.95);
    padding: 14px 28px;
    box-shadow: 0 10px 25px rgba(0,0,0,.15);
    display: flex;
    gap: 26px;
}

.tz-nav a {
    text-decoration: none;
    font-weight: 700;
    color: #0a1a3a;
    padding: 8px 16px;
    border-radius: 999px;
    transition: .25s;
}

.tz-nav a:hover,
.tz-nav .active {
    background: linear-gradient(135deg,#ffd400,#ff9800);
    color: #000;
    box-shadow: 0 6px 15px rgba(255,152,0,.45);
}
/* =========================
   FIX DROPDOWN USER
========================= */
.dropdown-menu {
    background: rgba(20, 30, 80, 0.95) !important;
    backdrop-filter: blur(10px);
    border-radius: 14px;
    border: none;
    box-shadow: 0 15px 40px rgba(0,0,0,0.45);
    padding: 10px 0;
    min-width: 220px;
}

/* Item */
.dropdown-menu .dropdown-item {
    color: #fff !important;
    font-weight: 600;
    padding: 12px 20px;
    transition: .25s;
    display: flex;
    align-items: center;
    gap: 10px;
}

/* Hover */
.dropdown-menu .dropdown-item:hover {
    background: linear-gradient(135deg,#ffd400,#ff9800);
    color: #000 !important;
}

/* Icon trong dropdown */
.dropdown-menu .bi {
    font-size: 18px;
}


  </style>
</head>

<body>

  <!-- HEADER -->
  <header class="tz-header">

    <div class="tz-logo">
      <i class="bi bi-cpu"></i> TechZone
    </div>

    <div class="tz-search">
      <form action="/tim-kiem" method="GET">
          <input id="search-input" name="key" type="text" placeholder="Tìm kiếm sản phẩm công nghệ..." required>
          <i id="search-icon" class="bi bi-search" onclick="this.closest('form').submit()"></i>
      </form>
    </div>


    <div class="tz-actions">
      <!-- <a href="/admin/login"><i class="bi bi-person"></i> Đăng nhập</a> -->
       @if(!session()->has('user_id'))
          <a href="/admin/login">
              <i class="bi bi-box-arrow-in-right"></i> Đăng nhập
          </a>
      @else
          <div class="dropdown">
            <div class="tz-city dropdown-toggle" data-bs-toggle="dropdown" style="cursor:pointer">
                <i class="bi bi-person-circle"></i>
                <strong>{{ session('username') }}</strong>
            </div>

            <ul class="dropdown-menu dropdown-menu-end">

                @if(session('role') === 'admin')
                    <li><a class="dropdown-item" href="/admin/danh-sach-nguoi-dung">
                        <i class="bi bi-people"></i> Quản lý người dùng
                    </a></li>
                @endif

                <!-- ⭐ THÊM LỊCH SỬ ĐƠN HÀNG Ở ĐÂY ⭐ -->
                <li><a class="dropdown-item" href="/lich-su-don-hang">
                    <i class="bi bi-clock-history"></i> Lịch sử đơn hàng
                </a></li>
                <!-- ⭐ HẾT PHẦN THÊM ⭐ -->

                <li><a class="dropdown-item" href="/admin/logout">
                    <i class="bi bi-box-arrow-right"></i> Đăng xuất
                </a></li>
            </ul>
        </div>

      @endif

      <a href="/cart">
        🛒 Giỏ hàng
        <span class="badge bg-danger">{{ $cartCount }}</span>
    </a>



      <div class="dropdown">
        <div class="tz-city dropdown-toggle" data-bs-toggle="dropdown">
          <i class="bi bi-geo-alt"></i>
          <span id="selected-city">Hồ Chí Minh</span>
        </div>

        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item active" onclick="selectCity('Hồ Chí Minh')">Hồ Chí Minh</a></li>
          <li><a class="dropdown-item" onclick="selectCity('Hà Nội')">Hà Nội</a></li>
          <li><a class="dropdown-item" onclick="selectCity('Đà Nẵng')">Đà Nẵng</a></li>
          <li><a class="dropdown-item" onclick="selectCity('Cần Thơ')">Cần Thơ</a></li>
        </ul>
      </div>
    </div>
  </header>

  <!-- NAVIGATION -->
  <nav class="tz-nav">
    <a class="active" href="/">Trang chủ</a>
    {{-- Nếu là admin → mở trang admin --}}
    @if(session('role') === 'admin')
        <a href="/admin/danh-sach-san-pham">Sản phẩm</a>
    @else
        <a href="/san-pham">Sản phẩm</a>
    @endif

    {{-- Chỉ admin mới thấy menu Người dùng --}}
    @if(session('role') === 'admin')
        <a href="/admin/danh-sach-nguoi-dung">Người dùng</a>
    @endif

    
  </nav>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <script>
    function selectCity(cityName) {
      document.getElementById("selected-city").innerText = cityName;
      document.querySelectorAll(".dropdown-item").forEach(i => i.classList.remove("active"));
      event.target.classList.add("active");
    }

    function handleSearch() {
      const input = document.getElementById("search-input").value.trim();
      if (input === "") return alert("Vui lòng nhập từ khóa!");

      console.log("Tìm kiếm:", input);

      // Ví dụ chuyển trang
      // window.location.href = "/tim-kiem?key=" + input;
    }

    document.addEventListener("DOMContentLoaded", () => {
      document.getElementById("search-input").addEventListener("keypress", e => {
        if (e.key === "Enter") handleSearch();
      });

      document.getElementById("search-icon").addEventListener("click", handleSearch);
    });
  </script>

</body>
</html>
