@if(session('logged_in') && session('role') === 'admin')
    @include('admin.template.header_admin')
@else
    @include('admin.template.header')
@endif

<style>
/* ====== NỀN TRANG ====== */
body {
    background: linear-gradient(135deg, #0f0f0f, #3a0ca3, #7209b7);
    min-height: 100vh;
}

/* ====== BỌC CONTAINER ====== */
.container {
    animation: fadeInUp 0.8s ease;
}

/* ====== TABLE GLASS EFFECT ====== */
.table {
    background: rgba(255, 255, 255, 0.12);
    backdrop-filter: blur(12px);
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 10px 35px rgba(0, 0, 0, 0.25);
}

/* ====== HEADER TABLE ====== */
.table-primary {
    background: linear-gradient(90deg, #4361ee, #7209b7);
    color: #fff;
    font-size: 18px;
}

/* ====== CỘT TITLE ====== */
.table .fw-bold td {
    color: #fff;
    background: rgba(255,255,255,0.08);
}

/* ====== ROW HOVER ====== */
.table tbody tr {
    transition: all 0.35s ease;
}

.table tbody tr:hover {
    background: rgba(255, 255, 255, 0.18);
    transform: scale(1.01);
}

/* ====== ẢNH SẢN PHẨM ====== */
.table img {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.table img:hover {
    transform: scale(1.15);
    box-shadow: 0 6px 20px rgba(0,0,0,0.5);
}

/* ====== BADGE ====== */
.badge {
    padding: 6px 12px;
    font-size: 13px;
    border-radius: 20px;
}

/* ====== BUTTON ====== */
.btn-success {
    background: linear-gradient(135deg, #38b000, #70e000);
    border: none;
    border-radius: 20px;
    padding: 6px 14px;
    transition: all 0.3s ease;
}

.btn-success:hover {
    transform: scale(1.1);
    box-shadow: 0 0 15px rgba(112, 224, 0, 0.8);
}

/* ====== LINK HÀNH ĐỘNG ====== */
a {
    text-decoration: none;
}

a:hover .badge {
    transform: scale(1.1);
}

/* ====== ANIMATION ====== */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(25px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>

<div class="container mt-4">

    <div class="row">
        <table class="table table-striped align-middle">

            <tr class="table-primary">
                <td colspan="7"><strong>Danh sách sản phẩm</strong></td>
            </tr>

            {{-- ⭐ Chỉ admin mới được thêm sản phẩm --}}
            <tr>
                <td colspan="5"></td>
                @if(session('role') === 'admin')
                    <td colspan="2">
                        <a href="them-san-pham" class="btn btn-success btn-sm">+ Thêm sản phẩm</a>
                    </td>
                @else
                    <td colspan="2"></td>
                @endif
            </tr>

            <tr class="fw-bold">
                <td>Tên</td>
                <td>Giá</td>
                <td>Ảnh</td>
                <td>Danh mục</td>

                @if(session('role') === 'admin')
                    <td>Trạng thái</td>
                    <td>Sửa</td>
                    <td>Ẩn / Hiện</td>
                @endif
            </tr>


            @foreach ($products as $product)
            <tr>
                <td>{{ $product->product_name }}</td>
                <td>{{ number_format($product->product_price, 0) }}</td>

                <td>
                    <img src="{{ $product->product_img }}" width="90"
                        style="border-radius:6px; border:1px solid #ddd;">
                </td>

                <td>{{ $product->category_name }}</td>

                @if(session('role') === 'admin')
                    {{-- TRẠNG THÁI --}}
                    <td>
                        @if($product->is_active)
                            <span class="badge bg-success">Đang bán</span>
                        @else
                            <span class="badge bg-secondary">Đã ẩn</span>
                        @endif
                    </td>

                    {{-- SỬA --}}
                    <td>
                        <a href="thong-tin-san-pham/{{ $product->product_id }}">
                            <img src="https://cdn-icons-png.flaticon.com/512/1159/1159633.png"
                                width="26">
                        </a>
                    </td>

                    {{-- ẨN / KHÔI PHỤC --}}
                    <td>
                        @if($product->is_active)
                            <a href="xoa-san-pham/{{ $product->product_id }}"
                            onclick="return confirm('Ẩn sản phẩm này khỏi website?')">
                                <span class="badge bg-danger">Ẩn</span>
                            </a>
                        @else
                            <a href="khoi-phuc-san-pham/{{ $product->product_id }}"
                            onclick="return confirm('Khôi phục sản phẩm này?')">
                                <span class="badge bg-warning text-dark">Hiện</span>
                            </a>
                        @endif
                    </td>
                @endif
            </tr>
            @endforeach


        </table>
    </div>

</div>

@include('admin/template/footer')
