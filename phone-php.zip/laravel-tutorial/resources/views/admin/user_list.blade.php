@if(session('logged_in') && session('role') === 'admin')
    @include('admin.template.header_admin')
@else
    @include('admin.template.header')
@endif

<style>
   .row {
      margin: 30px auto;
      width: 90%;
      max-width: 1000px;
   }

   table.table {
      width: 100%;
      border-collapse: collapse;
      background: #fff;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      border-radius: 8px;
      overflow: hidden;
   }

   table.table th, table.table td {
      padding: 12px 16px;
      text-align: left;
      border-bottom: 1px solid #ddd;
   }

   table.table tr:nth-child(even) {
      background-color: #f9f9f9;
   }

   table.table tr:hover {
      background-color: #f1f1f1;
   }

   table.table tr:first-child td {
      background-color: #007bff;
      color: #fff;
      font-weight: bold;
      text-align: center;
      font-size: 18px;
   }

   .btn-add {
      display: inline-block;
      background: #28a745;
      color: white;
      padding: 8px 16px;
      border-radius: 4px;
      text-decoration: none;
   }

   .btn-add:hover {
      background: #218838;
   }

   img {
      transition: transform 0.2s;
   }

   img:hover {
      transform: scale(1.1);
   }
</style>

<div class="row">
   <table class="table table-striped">
      <tr><td colspan="5">Danh sách người dùng</td></tr>

      {{-- ⭐ Chỉ admin mới được thêm người dùng --}}
      <tr>
         <td colspan="3"></td>
         @if(session('role') === 'admin')
            <td colspan="2" style="text-align: right;">
               <a href="them-nguoi-dung" class="btn-add">+ Thêm người dùng</a>
            </td>
         @else
            <td colspan="2"></td>
         @endif
      </tr>

      <tr>
         <td><strong>Tài khoản</strong></td>
         <td><strong>Họ tên</strong></td>
         <td><strong>Địa chỉ</strong></td>

         {{--  Chỉ admin mới xem nút sửa/xóa --}}
         @if(session('role') === 'admin')
            <td></td>
            <td></td>
         @endif
      </tr>

      @foreach ($users as $user)
      <tr>
         <td>{{ $user->user_username }}</td>
         <td>{{ $user->user_fullname }}</td>
         <td>{{ $user->user_address }}</td>

         {{-- Nút sửa, xóa chỉ admin mới thấy --}}
         @if(session('role') === 'admin')
            <td>
               <a href="thong-tin-nguoi-dung/{{ $user->user_id }}">
                  <img src="https://www.shutterstock.com/image-vector/edit-icon-vector-illustration-document-260nw-2222488095.jpg" width="30" alt="Edit">
               </a>
            </td>
            <td>
               <a href="xoa-nguoi-dung/{{ $user->user_id }}" onclick="return confirm('Xóa người dùng?')">
                  <img src="https://www.shutterstock.com/image-vector/close-icon-delete-symbol-wrong-260nw-1131132059.jpg" width="30" alt="Delete">
               </a>
            </td>
         @endif

      </tr>
      @endforeach
   </table>
</div>

@include('admin/template/footer')
