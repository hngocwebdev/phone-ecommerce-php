<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\OrderController;
use App\Http\Middleware\CheckAdmin;
use App\Http\Controllers\CheckoutController;
/*
|--------------------------------------------------------------------------
| FRONTEND – USER
|--------------------------------------------------------------------------
*/

// Trang chủ
Route::get('/', [ProductController::class, 'homepage']);

// Sản phẩm
Route::get('/san-pham', [ProductController::class, 'user_list']);
Route::get('/san-pham/{id}', [ProductController::class, 'detail']);

// Tìm kiếm
Route::get('/tim-kiem', [ProductController::class, 'search']);


/*
|--------------------------------------------------------------------------
| GIỎ HÀNG (USER)
|--------------------------------------------------------------------------
*/
Route::post('/add-to-cart/{id}', [CartController::class, 'add']);
Route::get('/cart', [CartController::class, 'view']);
Route::post('/cart/update', [CartController::class, 'update']);
Route::get('/cart/remove/{id}', [CartController::class, 'remove']);


/*
|--------------------------------------------------------------------------
| CHECKOUT (USER)
|--------------------------------------------------------------------------
*/
// Route::get('/checkout', [OrderController::class, 'form']);
// Route::post('/checkout/confirm', [OrderController::class, 'confirm']);
// Route::post('/checkout/done', [OrderController::class, 'done']);

Route::get('/checkout', [CheckoutController::class, 'form']);
Route::get('/checkout/success/{orderId}', [CheckoutController::class, 'success']);
Route::post('/checkout/confirm', [CheckoutController::class, 'confirm']);
Route::post('/checkout/done', [CheckoutController::class, 'done']);
Route::post('/cart/update-ajax', [CartController::class, 'updateAjax']);


/*
|--------------------------------------------------------------------------
| USER – LỊCH SỬ ĐƠN HÀNG
|--------------------------------------------------------------------------
*/
Route::get('/lich-su-don-hang', [OrderController::class, 'userOrderHistory']);


/*
|--------------------------------------------------------------------------
| AUTH
|--------------------------------------------------------------------------
*/
Route::get('/admin/login', [UserController::class, 'login_form']);
Route::post('/admin/xu-ly-login', [UserController::class, 'action_login']);

Route::get('/admin/logout', function () {
    session()->flush();
    return redirect('/admin/login');
});


/*
|--------------------------------------------------------------------------
| REGISTER (USER)
|--------------------------------------------------------------------------
*/
Route::get('/register', [UserController::class, 'registerForm']);
Route::post('/register', [UserController::class, 'register']);


/*
|--------------------------------------------------------------------------
| ADMIN – CHECK ADMIN MIDDLEWARE
|--------------------------------------------------------------------------
*/
Route::middleware([CheckAdmin::class])->prefix('admin')->group(function () {

    /*
    |------------------------------
    | QUẢN LÝ NGƯỜI DÙNG
    |------------------------------
    */
    Route::get('/them-nguoi-dung', [UserController::class, 'insert_form']);
    Route::post('/xu-ly-them-nguoi-dung', [UserController::class, 'action_insert']);
    Route::get('/danh-sach-nguoi-dung', [UserController::class, 'get_all']);
    Route::get('/xoa-nguoi-dung/{id}', [UserController::class, 'del']);
    Route::get('/thong-tin-nguoi-dung/{id}', [UserController::class, 'show']);
    Route::post('/xu-ly-cap-nhat-nguoi-dung', [UserController::class, 'action_update']);

    /*
    |------------------------------
    | QUẢN LÝ SẢN PHẨM
    |------------------------------
    */
    Route::get('/them-san-pham', [ProductController::class, 'insert_form']);
    Route::post('/xu-ly-them-san-pham', [ProductController::class, 'action_insert']);
    Route::get('/danh-sach-san-pham', [ProductController::class, 'admin_product_list']);
    Route::get('/xoa-san-pham/{id}', [ProductController::class, 'del']);
    Route::get('/khoi-phuc-san-pham/{id}', [ProductController::class, 'restore']);
    Route::get('/thong-tin-san-pham/{id}', [ProductController::class, 'show']);
    Route::post('/xu-ly-cap-nhat-san-pham', [ProductController::class, 'action_update']);

    /*
    |------------------------------
    | ĐƠN HÀNG – ADMIN
    |------------------------------
    */
    Route::get('/orders', [OrderController::class, 'adminOrderList']);
    Route::get('/orders/{id}', [OrderController::class, 'adminOrderDetail']);
    Route::get('/orders/delete/{id}', [OrderController::class, 'adminOrderDelete']);
});

// Buy Now
// Buy Now
Route::get('/buy-now/{id}', [OrderController::class, 'buyNow']);


Route::get('/admin/orders/delete-all', [OrderController::class, 'deleteAll']);

