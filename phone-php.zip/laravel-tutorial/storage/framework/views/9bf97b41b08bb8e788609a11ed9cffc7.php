<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>TechZone</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background: linear-gradient(135deg, #0f0f0f, #3a0ca3, #7209b7);
      margin: 0;
      font-family: "Segoe UI", sans-serif;
    }

    /* HEADER */
    .tz-header {
      background: #0a1a3a;
      padding: 18px 30px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }

    .tz-logo {
      display: flex;
      align-items: center;
      gap: 10px;
      color: #ffd400;
      font-size: 28px;
      font-weight: 800;
      letter-spacing: 1px;
      text-transform: uppercase;
    }

    /* SEARCH */
    .tz-search {
      flex: 1;
      max-width: 520px;
      position: relative;
      margin: 10px 25px;
    }

    .tz-search input {
      width: 100%;
      padding: 12px 45px 12px 17px;
      border-radius: 10px;
      border: none;
      outline: none;
      background: #fff;
      font-size: 15px;
    }

    #search-icon {
      position: absolute;
      right: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: #333;
      font-size: 18px;
      cursor: pointer;
    }

    /* ACTIONS */
    .tz-actions {
      display: flex;
      align-items: center;
      gap: 18px;
    }

    .tz-actions a {
      text-decoration: none;
      color: white;
      font-weight: 600;
      padding: 8px 14px;
      border-radius: 8px;
      background: #13254b;
      display: flex;
      align-items: center;
      gap: 6px;
      transition: 0.25s;
    }

    .tz-actions a:hover {
      background: #1e3b7c;
    }

    .tz-city {
      background: #13254b;
      padding: 8px 14px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      color: #fff;
      gap: 6px;
      font-weight: 600;
      cursor: pointer;
    }

    /* NAV */
    .tz-nav {
      background: #ffffff;
      padding: 12px 25px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      display: flex;
      gap: 25px;
    }

    .tz-nav a {
      text-decoration: none;
      font-weight: 600;
      color: #0a1a3a;
      padding: 6px 12px;
      border-radius: 6px;
      transition: 0.2s;
    }

    .tz-nav a:hover,
    .tz-nav .active {
      background: #ffd400;
      color: #0a1a3a;
    }
  </style>
</head>

<body>

<!-- HEADER -->
<header class="tz-header">

  <div class="tz-logo">
    <i class="bi bi-cpu"></i> TechZone
  </div>

  <!-- SEARCH -->
  <div class="tz-search">
    <form action="/tim-kiem" method="GET">
      <input name="key" type="text" placeholder="Tìm kiếm sản phẩm công nghệ..." required>
      <i id="search-icon" class="bi bi-search" onclick="this.closest('form').submit()"></i>
    </form>
  </div>

  <!-- ACTIONS -->
  <div class="tz-actions">

    <?php if(!session()->has('user_id')): ?>
      <a href="/admin/login">
        <i class="bi bi-box-arrow-in-right"></i> Đăng nhập
      </a>
    <?php else: ?>
      <div class="dropdown">
        <div class="tz-city dropdown-toggle" data-bs-toggle="dropdown">
          <i class="bi bi-person-circle"></i>
          <strong><?php echo e(session('username')); ?></strong>
        </div>

        <ul class="dropdown-menu dropdown-menu-end">
          <?php if(session('role') === 'admin'): ?>
            <li>
              <a class="dropdown-item" href="/admin/danh-sach-nguoi-dung">
                <i class="bi bi-people"></i> Quản lý người dùng
              </a>
            </li>
          <?php endif; ?>

          <li>
            <a class="dropdown-item" href="/admin/orders">
              <i class="bi bi-clock-history"></i> Danh sách đơn hàng
            </a>
          </li>

          <li>
            <a class="dropdown-item" href="/admin/logout">
              <i class="bi bi-box-arrow-right"></i> Đăng xuất
            </a>
          </li>
        </ul>
      </div>
    <?php endif; ?>

    <div class="dropdown">
      <div class="tz-city dropdown-toggle" data-bs-toggle="dropdown">
        <i class="bi bi-geo-alt"></i>
        <span>Hồ Chí Minh</span>
      </div>

      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item active">Hồ Chí Minh</a></li>
        <li><a class="dropdown-item">Hà Nội</a></li>
        <li><a class="dropdown-item">Đà Nẵng</a></li>
        <li><a class="dropdown-item">Cần Thơ</a></li>
      </ul>
    </div>

  </div>
</header>

<!-- NAV -->
<nav class="tz-nav">
  <a class="active" href="/">Trang chủ</a>

  <?php if(session('role') === 'admin'): ?>
    <a href="/admin/danh-sach-san-pham">Sản phẩm</a>
    <a href="/admin/danh-sach-nguoi-dung">Người dùng</a>
  <?php else: ?>
    <a href="/san-pham">Sản phẩm</a>
  <?php endif; ?>
</nav>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php /**PATH C:\wbtm\laravel-tutorial\laravel-tutorial\resources\views/admin/template/header_admin.blade.php ENDPATH**/ ?>