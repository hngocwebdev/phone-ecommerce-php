<?php if(session('logged_in') && session('role') === 'admin'): ?>
    <?php echo $__env->make('admin.template.header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('admin.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<style>
@keyframes fadeUp {
    from { opacity: 0; transform: translateY(50px) scale(.96); }
    to { opacity: 1; transform: translateY(0) scale(1); }
}

/* ===== WRAPPER ===== */
.order-wrapper {
    max-width: 1100px;
    margin: 70px auto;
    padding: 45px;
    border-radius: 32px;
    background: linear-gradient(135deg,#1b1f63,#6a11cb);
    box-shadow: 0 55px 130px rgba(0,0,0,.65);
    color: #fff;
    animation: fadeUp .9s ease forwards;
}

/* ===== TITLE ===== */
.order-title {
    font-size: 38px;
    font-weight: 900;
    text-align: center;
    color: #2cff9a;
    margin-bottom: 40px;
}

/* ===== EMPTY ===== */
.order-empty {
    text-align: center;
    font-size: 18px;
    opacity: .85;
}

/* ===== ORDER CARD ===== */
.order-card {
    background: rgba(255,255,255,.08);
    border-radius: 24px;
    padding: 26px 30px;
    margin-bottom: 22px;
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 20px;
    transition: .35s;
    position: relative;
}

.order-card:hover {
    transform: translateY(-6px);
    background: rgba(255,255,255,.14);
    box-shadow: 0 25px 55px rgba(0,0,0,.4);
}

/* ===== LEFT INFO ===== */
.order-info h5 {
    font-size: 18px;
    font-weight: 800;
    margin-bottom: 6px;
}

.order-meta {
    font-size: 14px;
    opacity: .85;
}

/* ===== PRICE ===== */
.order-price {
    font-size: 26px;
    font-weight: 900;
    color: #ffd54f;
    text-align: right;
}

/* ===== DATE ===== */
.order-date {
    font-size: 13px;
    opacity: .8;
    margin-top: 6px;
    text-align: right;
}

/* ===== ADMIN INFO ===== */
.admin-info {
    font-size: 13px;
    opacity: .85;
    margin-top: 8px;
}

/* ===== STATUS BADGE ===== */
.order-status {
    position: absolute;
    top: -12px;
    left: 22px;
    background: linear-gradient(135deg,#2cff9a,#00e676);
    color: #003;
    font-size: 12px;
    font-weight: 800;
    padding: 6px 14px;
    border-radius: 999px;
}

/* ===== MOBILE ===== */
@media (max-width: 768px) {
    .order-wrapper {
        padding: 25px;
        margin: 30px 15px;
    }

    .order-card {
        grid-template-columns: 1fr;
    }

    .order-price,
    .order-date {
        text-align: left;
    }
}
</style>

<div class="order-wrapper">

    <div class="order-title">
        📦 Lịch sử đơn hàng
    </div>

    <?php if(session('error')): ?>
        <div class="alert alert-danger mb-4">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if($orders->isEmpty()): ?>
        <div class="order-empty">
            Bạn chưa có đơn hàng nào.
        </div>
    <?php else: ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="order-card">

                <div class="order-status">
                    Đã đặt
                </div>

                
                <div class="order-info">
                    <h5>
                        Đơn hàng #<?php echo e($o->order_code ?? '—'); ?>

                    </h5>

                    <div class="order-meta">
                        <?php if(session('role') === 'admin'): ?>
                            <div class="admin-info">
                                👤 <?php echo e($o->fullname); ?> · 📞 <?php echo e($o->phone); ?>

                            </div>
                            <div class="admin-info">
                                📍 <?php echo e($o->address); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div>
                    <div class="order-price">
                        <?php echo e(number_format($o->total)); ?> đ
                    </div>

                    <div class="order-date">
                        <?php echo e(\Carbon\Carbon::parse($o->created_at)->format('d/m/Y H:i')); ?>

                    </div>
                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

</div>

<?php echo $__env->make('admin.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wbtm\laravel-tutorial\23662010_NguyenThiHongNgoc\laravel-tutorial\resources\views/user/order_list.blade.php ENDPATH**/ ?>