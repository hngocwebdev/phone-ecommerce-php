<?php if(session('logged_in') && session('role') === 'admin'): ?>
    <?php echo $__env->make('admin.template.header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('admin.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>


<style>
/* =====================
   CARD CONTAINER
===================== */
.card {
    border-radius: 18px;
    overflow: hidden;
    background: rgba(255,255,255,0.95);
    transition: all 0.35s ease;
    position: relative;
}

/* Hiệu ứng nổi khi hover */
.card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 20px 35px rgba(0,0,0,0.35);
}

/* =====================
   IMAGE
===================== */
.card-img-top {
    height: 180px;
    object-fit: contain;
    padding: 14px;
    background: linear-gradient(135deg, #ffffff, #f1f3f9);
    transition: transform 0.4s ease;
}

/* Ảnh zoom nhẹ khi hover */
.card:hover .card-img-top {
    transform: scale(1.12) rotate(-1deg);
}

/* =====================
   CARD BODY
===================== */
.card-body {
    text-align: center;
    padding: 18px;
}

/* Tên sản phẩm */
.card-body h5 {
    font-size: 16px;
    font-weight: 700;
    color: #0a1a3a;
    min-height: 40px;
    transition: color 0.3s;
}

.card:hover .card-body h5 {
    color: #3a0ca3;
}

/* Giá */
.card-body p {
    font-size: 18px;
    margin-bottom: 14px;
}

/* =====================
   BUTTONS
===================== */
.card .btn {
    font-weight: 700;
    border-radius: 10px;
    transition: all 0.3s ease;
}

/* Nút Đặt hàng */
.card .btn-primary {
    background: linear-gradient(135deg, #4361ee, #3a0ca3);
    border: none;
}

.card .btn-primary:hover {
    background: linear-gradient(135deg, #4cc9f0, #4895ef);
    transform: translateY(-2px);
}

/* Nút admin */
.card .btn-warning {
    background: linear-gradient(135deg, #f9c74f, #f8961e);
    border: none;
    color: #000;
}

.card .btn-danger {
    background: linear-gradient(135deg, #ef233c, #d90429);
    border: none;
}

/* =====================
   ADMIN BUTTON GROUP
===================== */
.card .d-flex a {
    font-size: 13px;
    padding: 6px 0;
}

/* =====================
   FADE-IN KHI LOAD
===================== */
.col-md-3 {
    animation: fadeUp 0.6s ease forwards;
}

@keyframes fadeUp {
    from {
        opacity: 0;
        transform: translateY(25px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* =====================
   RESPONSIVE
===================== */
@media (max-width: 768px) {
    .card-img-top {
        height: 150px;
    }
}

.product-title {
    text-align: center;
    font-size: 36px;
    font-weight: 900;
    color: #ffd400;
    letter-spacing: 1px;
    text-transform: uppercase;
    text-shadow: 0 4px 15px rgba(0,0,0,0.5);
    animation: glow 2s infinite alternate;
}

@keyframes glow {
    from {
        text-shadow: 0 0 10px rgba(255,212,0,0.6);
    }
    to {
        text-shadow: 0 0 22px rgba(255,212,0,0.95);
    }
}
.price-box {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
}

/* Giá gốc */
.old-price {
    text-decoration: line-through;
    color: #999;
    font-size: 14px;
}

/* Giá sale */
.sale-price {
    font-size: 20px;
    font-weight: 800;
    color: #e63946;
}

/* Badge giảm giá */
.sale-badge {
    position: absolute;
    top: -8px;
    right: -8px;
    background: linear-gradient(135deg, #ffbe0b, #fb5607);
    color: #000;
    font-size: 12px;
    font-weight: 900;
    padding: 4px 8px;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.35);
}


</style>


<div class="container mt-5">

    <h2 class="product-title mb-5">
    🔥 Danh sách sản phẩm 🔥
    </h2>


    
    <?php if(session('role') === 'admin'): ?>
        <a href="/admin/them-san-pham" class="btn btn-success mb-4">
            + Thêm sản phẩm
        </a>
    <?php endif; ?>

    <div class="row">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 mb-4">
            <div class="card shadow">

                <a href="/san-pham/<?php echo e($product->product_id); ?>">
                    <img src="<?php echo e($product->product_img); ?>" class="card-img-top">
                </a>


                <div class="card-body">
                    <h5 class="fw-semibold"><?php echo e($product->product_name); ?></h5>
                    <?php
                            $salePercent = 20; // % giảm giá
                            $salePrice = $product->product_price * (100 - $salePercent) / 100;
                        ?>

                        <div class="price-box mb-3">
                            <span class="old-price">
                                <?php echo e(number_format($product->product_price)); ?> đ
                            </span>

                            <span class="sale-price">
                                <?php echo e(number_format($salePrice)); ?> đ
                            </span>

                            <span class="sale-badge">
                                -<?php echo e($salePercent); ?>%
                            </span>
                        </div>


                    
                    <a href="/san-pham/<?php echo e($product->product_id); ?>" 
                       class="btn btn-primary btn-sm w-100">
                       Đặt hàng
                    </a>

                    
                    <?php if(session('role') === 'admin'): ?>
                    <div class="d-flex justify-content-between mt-2">
                        <a href="/admin/thong-tin-san-pham/<?php echo e($product->product_id); ?>" 
                           class="btn btn-warning btn-sm w-50 me-1">
                           Sửa
                        </a>

                        <a href="/admin/xoa-san-pham/<?php echo e($product->product_id); ?>"
                           onclick="return confirm('Bạn có chắc muốn xóa?')"
                           class="btn btn-danger btn-sm w-50 ms-1">
                           Xóa
                        </a>
                    </div>
                    <?php endif; ?>

                </div>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</div>

<?php echo $__env->make('admin/template/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wbtm\laravel-tutorial\23662010_NguyenThiHongNgoc\laravel-tutorial\resources\views/user/product_list.blade.php ENDPATH**/ ?>