<!-- FONT AWESOME -->
<link rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<!-- FOOTER STYLE -->
<style>
    
/* =========================
   FOOTER CONTAINER
========================= */
.footer-area {
    margin-top: 80px;
    padding: 60px 0 30px;
    background: linear-gradient(135deg,#0a1a3a,#3a0ca3);
    position: relative;
    overflow: hidden;
}

/* Glow background */
.footer-area::before {
    content: "";
    position: absolute;
    inset: 0;
    background: radial-gradient(circle at top,
        rgba(255,255,255,0.08),
        transparent 70%);
    pointer-events: none;
}

/* =========================
   FOOTER MAIN BOX
========================= */
.footer-main {
    background: rgba(255,255,255,0.08);
    backdrop-filter: blur(12px);
    border-radius: 24px;
    padding: 40px;
    box-shadow: 0 25px 60px rgba(0,0,0,0.45);
}

/* =========================
   TITLES
========================= */
.footer-title {
    font-size: 22px;
    font-weight: 800;
    margin-bottom: 20px;
    color: #ffd400;
    letter-spacing: .5px;
}

/* =========================
   TEXT
========================= */
.footer-area p {
    margin-bottom: 10px;
    font-size: 15px;
    color: #e0e0e0;
    line-height: 1.6;
}

/* =========================
   GOOGLE MAP
========================= */
.footer-area iframe {
    border-radius: 16px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.35);
    transition: transform .35s ease, box-shadow .35s ease;
}

.footer-area iframe:hover {
    transform: scale(1.02);
    box-shadow: 0 25px 55px rgba(0,0,0,0.5);
}

/* =========================
   SOCIAL LINKS
========================= */
.social-links {
    display: flex;
    gap: 14px;
    margin-top: 14px;
}

.social-links a {
    width: 44px;
    height: 44px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    color: white;
    font-size: 18px;
    transition: .35s ease;
    text-decoration: none;
    box-shadow: 0 8px 20px rgba(0,0,0,0.35);
}

/* Facebook */
.social-links a.fb {
    background: linear-gradient(135deg,#1877f2,#3b5998);
}

/* Instagram */
.social-links a.ig {
    background: linear-gradient(45deg,#f58529,#dd2a7b,#8134af);
}

/* Zalo */
.social-links a.zalo {
    background: linear-gradient(135deg,#0068ff,#00b0ff);
}

/* Hover effect */
.social-links a:hover {
    transform: translateY(-6px) scale(1.08);
    box-shadow: 0 15px 35px rgba(0,0,0,0.5);
    opacity: 0.95;
}

/* =========================
   RESPONSIVE
========================= */
@media (max-width: 768px) {
    .footer-main {
        padding: 25px;
    }

    .footer-title {
        font-size: 20px;
    }
}

</style>

<!-- FOOTER -->
<footer class="footer-area">
    <div class="footer-main container">
        <div class="row">

            <!-- COL 1: GOOGLE MAP -->
            <div class="col-md-6 col-12 mb-4">
                <h5 class="footer-title">📍 Địa chỉ cửa hàng</h5>

                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.6055312745702!2d106.6733253!3d10.7648539!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752ee10a9f249b%3A0x54af0b8f63e60391!2zMzMgVsSpbmggVmnhu4VuLCBQaMaw4budbmcgMiwgUXXhuq1uIDEwLCBUaMOgbmggcGjhu5EgSOG7kyBDaMOtIE1pbmg!5e0!3m2!1svi!2s!4v1763429865947!5m2!1svi!2s"
                    width="100%"
                    height="300"
                    style="border:0; border-radius:12px;"
                    loading="lazy">
                </iframe>
            </div>

            <!-- COL 2: CONTACT -->
            <div class="col-md-6 col-12">
                <h5 class="footer-title">📞 Liên hệ</h5>

                <p>🏠 <strong>33 Vĩnh Viễn, Quận 10, TP.HCM</strong></p>
                <p>📧 Email: <strong>support@shopmall.vn</strong></p>
                <p>☎ Hotline: <strong>0901 234 567</strong></p>

                <h6 class="footer-title mt-4">🌐 Mạng xã hội</h6>
                <div class="social-links">
                    <a href="https://www.facebook.com/" target="_blank" class="fb">
                        <i class="fab fa-facebook-f"></i>
                    </a>

                    <a href="https://www.instagram.com/" target="_blank" class="ig">
                        <i class="fab fa-instagram"></i>
                    </a>

                    <a href="https://zalo.me/" target="_blank" class="zalo">
                        <i class="fa-solid fa-comment-dots"></i>
                    </a>
                </div>
            </div>

        </div>
    </div>
</footer>
<?php /**PATH C:\wbtm\laravel-tutorial\23662010_NguyenThiHongNgoc\laravel-tutorial\resources\views/admin/template/footer.blade.php ENDPATH**/ ?>