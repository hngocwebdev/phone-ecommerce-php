<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin – Cập nhật sản phẩm</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
/* ================= ROOT ================= */
:root{
    --accent:#7c4dff;
    --accent2:#00e5ff;
    --glass:rgba(255,255,255,0.12);
    --glass-border:rgba(255,255,255,0.25);
}

/* ================= BODY ================= */
body{
    margin:0;
    font-family:"Segoe UI",system-ui;
    background:
        radial-gradient(circle at top left,#3a0ca3,transparent 45%),
        radial-gradient(circle at bottom right,#7209b7,transparent 45%),
        linear-gradient(135deg,#0a0a0a,#0f0f1a);
    color:#fff;
}

/* ================= SIDEBAR ================= */
.sidebar{
    width:260px;
    height:100vh;
    position:fixed;
    left:0;
    top:0;
    background:var(--glass);
    backdrop-filter:blur(20px);
    -webkit-backdrop-filter:blur(20px);
    border-right:1px solid var(--glass-border);
    box-shadow:4px 0 35px rgba(0,0,0,.6);
    padding-top:30px;
}

.sidebar h4{
    text-align:center;
    font-weight:800;
    letter-spacing:1px;
    margin-bottom:35px;
    color:#ffd166;
}

/* ================= MENU ================= */
.menu-link{
    display:flex;
    align-items:center;
    gap:12px;
    padding:15px 22px;
    margin:8px 15px;
    border-radius:14px;
    color:#fff;
    text-decoration:none;
    font-weight:500;
    transition:.35s;
}

.menu-link:hover{
    background:linear-gradient(135deg,var(--accent),var(--accent2));
    box-shadow:0 0 25px rgba(124,77,255,.7);
    transform:translateX(6px);
}

/* ================= CONTENT ================= */
.content{
    margin-left:260px;
    padding:35px;
    animation:fadeUp .8s ease;
}

/* ================= HEADER ================= */
.top-header{
    background:var(--glass);
    backdrop-filter:blur(18px);
    border:1px solid var(--glass-border);
    padding:20px 30px;
    border-radius:18px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 15px 40px rgba(0,0,0,.6);
    margin-bottom:35px;
}

.top-header h4{
    font-weight:800;
    letter-spacing:.5px;
}

/* ================= CARD ================= */
.update-card{
    background:var(--glass);
    backdrop-filter:blur(22px);
    border-radius:22px;
    padding:40px;
    border:1px solid var(--glass-border);
    box-shadow:
        0 30px 70px rgba(0,0,0,.65),
        inset 0 0 0 1px rgba(255,255,255,.05);
}

/* ================= FORM ================= */
.form-label{
    font-weight:600;
    color:#e0e0ff;
}

.form-control,
.form-select,
textarea{
    background:rgba(255,255,255,0.15);
    border:1px solid rgba(255,255,255,0.25);
    color:#fff;
    border-radius:14px;
    padding:12px 15px;
    transition:.3s;
}

.form-control::placeholder,
textarea::placeholder{
    color:#cfcfcf;
}

.form-control:focus,
.form-select:focus,
textarea:focus{
    background:rgba(255,255,255,0.22);
    border-color:var(--accent2);
    box-shadow:0 0 0 3px rgba(0,229,255,.25);
    color:#fff;
}

/* ================= IMAGE ================= */
.product-img{
    margin-top:15px;
    border-radius:16px;
    border:1px solid rgba(255,255,255,.3);
    transition:.4s;
}

.product-img:hover{
    transform:scale(1.25);
    box-shadow:0 20px 45px rgba(0,0,0,.8);
}

/* ================= BUTTON ================= */
.btn-save{
    background:linear-gradient(135deg,var(--accent),var(--accent2));
    border:none;
    padding:12px 40px;
    border-radius:30px;
    color:#fff;
    font-weight:700;
    letter-spacing:.5px;
    transition:.35s;
}

.btn-save:hover{
    transform:translateY(-3px) scale(1.08);
    box-shadow:0 0 35px rgba(124,77,255,.9);
}

.btn-back{
    border-radius:30px;
    padding:12px 30px;
}

/* ================= ANIMATION ================= */
@keyframes fadeUp{
    from{opacity:0;transform:translateY(40px);}
    to{opacity:1;transform:none;}
}
</style>

</head>

<body>

    <!-- SIDEBAR -->
    <div class="sidebar">
        <h4>⚙ ADMIN PANEL</h4>

        <a href="/admin/danh-sach-san-pham" class="menu-link">📦 Quản lý sản phẩm</a>
        <a href="/admin/danh-sach-nguoi-dung" class="menu-link">👤 Người dùng</a>
    </div>

    <!-- CONTENT -->
    <div class="content">

        <!-- HEADER -->
        <div class="top-header">
            <h4 class="fw-bold">Cập nhật sản phẩm</h4>
            <div>👤 Admin</div>
        </div>

        <!-- MAIN -->
        <div class="update-card">
            <form action="/admin/xu-ly-cap-nhat-san-pham" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <!-- Không foreach nữa – chỉ dùng $product  -->
                <div class="row">

                    <!-- LEFT -->
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Tên sản phẩm</label>
                            <input type="text" name="name" class="form-control"
                                   value="<?php echo e($product->product_name); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Giá (VNĐ)</label>
                            <input type="number" name="price" class="form-control"
                                   value="<?php echo e($product->product_price); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Danh mục</label>
                            <select name="category" class="form-select">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->category_id); ?>"
                                    <?php echo e($category->category_id == $product->product_category ? 'selected' : ''); ?>>
                                    <?php echo e($category->category_name); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <!-- RIGHT -->
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Ảnh sản phẩm</label>
                            <input type="file" name="img" class="form-control">

                            <p class="text-center text-muted mt-2">— hoặc —</p>

                            <input type="text" name="img_link" class="form-control"
                                   placeholder="Dán link ảnh tại đây"
                                   value="<?php echo e($product->product_img); ?>">

                            <input type="hidden" name="img_old" value="<?php echo e($product->product_img); ?>">

                            <img src="<?php echo e(asset($product->product_img)); ?>" width="140" class="product-img">
                        </div>
                    </div>

                </div>

                <div class="mb-3">
                    <label class="form-label">Mô tả</label>
                    <textarea name="description" class="form-control" rows="4"><?php echo e($product->product_description); ?></textarea>
                </div>

                <input type="hidden" name="id" value="<?php echo e($product->product_id); ?>">

                <div class="mt-4">
                    <button type="submit" class="btn-save">💾 Lưu thay đổi</button>
                    <a href="/admin/danh-sach-san-pham" class="btn btn-outline-secondary btn-back">⬅ Quay lại</a>
                </div>

            </form>
        </div>

    </div>
</body>
</html>
<?php /**PATH C:\wbtm\laravel-tutorial\laravel-tutorial\resources\views/admin/product_info_form.blade.php ENDPATH**/ ?>