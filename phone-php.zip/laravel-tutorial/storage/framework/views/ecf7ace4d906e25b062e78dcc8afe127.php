<?php if(session('logged_in') && session('role') === 'admin'): ?>
    <?php echo $__env->make('admin.template.header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('admin.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>


<style>
    
    /* ==========================
       INTRO SECTION
    =========================== */
    .intro-section {
        padding: 70px 0;
        background: #ffffff;
    }

    .intro-text h2 {
        font-size: 40px;
        font-weight: 800;
        color: #1a1a1a;
        margin-bottom: 15px;
    }

    .intro-text p {
        font-size: 17px;
        color: #4c4c4c;
    }

    /* ==========================
       CATEGORY TITLE
    =========================== */
    .category-title {
        text-align: center;
        font-size: 38px;
        font-weight: 900;
        color: #ffffff;
        margin-top: 60px;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    /* ==========================
   PRODUCT CARD (PRO)
========================== */
.cate-card {
    width: 100%;
    max-width: 270px;
    border-radius: 22px;
    background: linear-gradient(160deg,#ffffff,#f1f1f1);
    box-shadow:
        0 18px 35px rgba(0,0,0,0.18),
        inset 0 0 0 1px rgba(255,255,255,0.8);
    transition: 0.45s cubic-bezier(.21,.8,.32,1);
    overflow: hidden;
    position: relative;
}

/* ánh sáng động */
.cate-card::before {
    content: "";
    position: absolute;
    inset: -80%;
    background: linear-gradient(120deg,
        transparent 40%,
        rgba(255,255,255,0.35),
        transparent 60%);
    transform: rotate(25deg);
    transition: 0.8s;
}

.cate-card:hover::before {
    inset: -20%;
}

.cate-card:hover {
    transform: translateY(-14px) scale(1.05);
    box-shadow:
        0 35px 65px rgba(0,0,0,0.35),
        inset 0 0 0 1px rgba(255,255,255,0.9);
}

/* ==========================
   IMAGE BOX
========================== */
.cate-img-box {
    height: 240px;
    background: radial-gradient(circle at top,#ffffff,#eaeaea);
    display: flex;
    justify-content: center;
    align-items: center;
    border-bottom: 1px solid #ddd;
    position: relative;
    overflow: hidden;
}

.cate-img-box::after {
    content: "";
    position: absolute;
    width: 160px;
    height: 160px;
    background: rgba(0,0,0,0.08);
    border-radius: 50%;
    filter: blur(28px);
}

.cate-img-box img {
    width: 88%;
    height: 88%;
    object-fit: contain;
    position: relative;
    z-index: 2;
    transition: transform 0.45s ease, filter 0.45s ease;
}

.cate-card:hover .cate-img-box img {
    transform: scale(1.18) rotate(-1deg);
    filter: drop-shadow(0 18px 35px rgba(0,0,0,0.35));
}

/* ==========================
   SALE BADGE (PRO)
========================== */
.sale-badge {
    position: absolute;
    top: 14px;
    left: 14px;
    background: linear-gradient(135deg,#ff1744,#ff9800);
    color: #fff;
    font-size: 13px;
    font-weight: 900;
    padding: 7px 14px;
    border-radius: 999px;
    box-shadow: 0 10px 25px rgba(255,0,0,0.45);
    animation: pulse 1.8s infinite;
    z-index: 10;
}

@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.08); }
    100% { transform: scale(1); }
}

/* ==========================
   TEXT
========================== */
.cate-info {
    padding: 18px;
    text-align: center;
}

.cate-name {
    font-size: 18px;
    font-weight: 800;
    color: #222;
    margin-bottom: 6px;
    height: 48px;
    overflow: hidden;
}

.price-old {
    font-size: 14px;
    color: #888;
    text-decoration: line-through;
}

.price-sale {
    font-size: 22px;
    font-weight: 900;
    color: #ff0033;
    text-shadow: 0 0 8px rgba(255,0,0,0.45);
    margin-bottom: 14px;
}

/* ==========================
   BUTTON (PRO)
========================== */
.btn-detail {
    width: 100%;
    padding: 12px;
    border-radius: 12px;
    background: linear-gradient(135deg,#007bff,#0047ff);
    color: #fff;
    font-weight: 800;
    border: none;
    box-shadow: 0 8px 18px rgba(0,123,255,0.45);
    transition: 0.35s;
}

.btn-detail:hover {
    background: linear-gradient(135deg,#0056d2,#0037b3);
    transform: translateY(-4px);
    box-shadow: 0 14px 28px rgba(0,123,255,0.6);
}

    /* ==========================
   SALE BADGE
========================== */
.sale-badge {
    position: absolute;
    top: 12px;
    left: 12px;
    background: linear-gradient(135deg, #ff5722, #ff9800);
    color: #fff;
    font-size: 13px;
    font-weight: 800;
    padding: 6px 12px;
    border-radius: 999px;
    box-shadow: 0 6px 15px rgba(0,0,0,0.35);
    z-index: 20;
}

/* ==========================
   PRICE STYLE
========================== */
.price-old {
    font-size: 14px;
    color: #888;
    text-decoration: line-through;
    margin-bottom: 2px;
}

.price-sale {
    font-size: 20px;
    font-weight: 900;
    color: #ff0033;
    text-shadow: 0 0 6px rgba(255,0,0,0.35);
    margin-bottom: 12px;
}

</style>

<!-- ==========================
     HERO BANNER
=========================== -->
<div class="hero-banner"></div>

<!-- ==========================
     INTRO SECTION
=========================== -->
<section class="intro-section container">
    <div class="row align-items-center">
        <div class="col-md-6 intro-text">
            <h2>Về TECHZONE</h2>
            <p>TECHZONE – Hành trình mang đến trải nghiệm công nghệ tốt nhất.</p>
        </div>

        <div class="col-md-6 text-center">
            <img src="https://cdn2.cellphones.com.vn/insecure/rs:fill:1036:450/q:100/plain/https://dashboard.cellphones.com.vn/storage/iphone-17-1225-home.png"
                 class="img-fluid rounded-4 border border-3 border-white shadow">
        </div>
    </div>
</section>

<!-- ==========================
     PRODUCT LIST
=========================== -->
<h2 id="product-section" class="category-title">Danh mục sản phẩm</h2>


<div class="container mt-4">
    <div class="row g-4">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $discountPercent = 20; // % giảm giá
            $salePrice = $p->product_price * (100 - $discountPercent) / 100;
        ?>

        <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex justify-content-center">
            <div class="cate-card">

                <div class="cate-img-box">
                    <span class="sale-badge">-<?php echo e($discountPercent); ?>%</span>

                    <a href="/san-pham/<?php echo e($p->product_id); ?>">
                        <img src="<?php echo e($p->product_img); ?>" alt="<?php echo e($p->product_name); ?>">
                    </a>
                </div>



                <div class="cate-info">
                    <p class="cate-name"><?php echo e($p->product_name); ?></p>
                    <div class="price-old">
                        <?php echo e(number_format($p->product_price)); ?>₫
                    </div>

                    <div class="price-sale">
                        <?php echo e(number_format($salePrice)); ?>₫
                    </div>


                    <?php if(session('logged_in')): ?>
                        
                        <?php if(session('role') === 'admin'): ?>
                            
                            <button class="btn-detail"
                                    style="background:#999; cursor:not-allowed;"
                                    onclick="alert('Admin không được phép đặt hàng!')">
                                Đặt hàng
                            </button>
                        <?php else: ?>
                            
                            <a href="/san-pham/<?php echo e($p->product_id); ?>"
                            class="btn-detail"
                            style="text-decoration:none;">
                                Đặt hàng
                            </a>
                        <?php endif; ?>
                    <?php else: ?>
                        
                        <a href="/admin/login"
                        class="btn-detail"
                        style="background:#f0ad4e; text-decoration:none;"
                        onclick="return confirm('Bạn cần đăng nhập để đặt hàng!')">
                            Đặt hàng
                        </a>
                    <?php endif; ?>

                </div>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<?php if(request()->has('key') && count($products) > 0): ?>
<script>
  window.addEventListener('load', function () {
    const section = document.getElementById('product-section');
    if (section) section.scrollIntoView({ behavior: 'smooth' });
  });
</script>
<?php endif; ?>

<?php echo $__env->make('admin.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wbtm\laravel-tutorial\laravel-tutorial\resources\views/welcome.blade.php ENDPATH**/ ?>