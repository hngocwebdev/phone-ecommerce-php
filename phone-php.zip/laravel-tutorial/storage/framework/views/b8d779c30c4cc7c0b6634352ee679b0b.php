<?php if(session('logged_in') && session('role') === 'admin'): ?>
    <?php echo $__env->make('admin.template.header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('admin.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<style>
/* ================= ROOT ================= */
:root{
    --gold: #ffd166;
    --purple: #7c4dff;
    --cyan: #00e5ff;
    --glass: rgba(255,255,255,0.12);
    --border-glass: rgba(255,255,255,0.25);
}

/* ================= BODY ================= */
body{
    background:
        radial-gradient(circle at top left, #3a0ca3, transparent 45%),
        radial-gradient(circle at bottom right, #7209b7, transparent 45%),
        linear-gradient(135deg, #0a0a0a, #0f0f1a);
    min-height:100vh;
    font-family: "Segoe UI", system-ui;
}

/* ================= TITLE ================= */
.page-title{
    text-align:center;
    color:#fff;
    font-size:38px;
    font-weight:800;
    margin-top:50px;
    letter-spacing:2px;
    text-shadow:0 0 20px rgba(124,77,255,.6);
}

/* ================= FORM CARD ================= */
.form-card{
    width:880px;
    margin:50px auto;
    background:var(--glass);
    backdrop-filter: blur(22px);
    -webkit-backdrop-filter: blur(22px);
    border-radius:24px;
    padding:45px 55px;
    border:1px solid var(--border-glass);
    box-shadow:
        0 30px 70px rgba(0,0,0,.65),
        inset 0 0 0 1px rgba(255,255,255,.05);
    animation: cinematicIn .9s ease;
}

/* ================= ANIMATION ================= */
@keyframes cinematicIn{
    from{opacity:0; transform:translateY(50px) scale(.95);}
    to{opacity:1; transform:none;}
}

/* ================= HEAD ================= */
.form-card h3{
    text-align:center;
    font-weight:800;
    margin-bottom:30px;
    color:var(--gold);
    letter-spacing:1px;
}

/* ================= SECTION TITLE ================= */
.form-section-title{
    font-weight:700;
    margin:30px 0 15px;
    color:#e0e0ff;
    text-transform:uppercase;
    letter-spacing:1px;
}

/* ================= INPUT ================= */
.form-control,
.form-select,
textarea{
    background:rgba(255,255,255,0.15);
    border:1px solid rgba(255,255,255,0.25);
    color:#fff;
    border-radius:14px;
    padding:12px 15px;
    transition:.35s;
}

.form-control::placeholder,
textarea::placeholder{
    color:#d0d0d0;
}

.form-control:focus,
.form-select:focus,
textarea:focus{
    background:rgba(255,255,255,0.2);
    border-color:var(--cyan);
    box-shadow:0 0 0 3px rgba(0,229,255,.25);
    color:#fff;
}

/* ================= PREVIEW ================= */
.preview-box{
    width:100%;
    height:240px;
    border-radius:18px;
    border:2px dashed rgba(255,255,255,0.35);
    display:flex;
    align-items:center;
    justify-content:center;
    background:rgba(255,255,255,0.08);
    margin-bottom:25px;
    position:relative;
    overflow:hidden;
}

.preview-box::after{
    content:"PREVIEW";
    position:absolute;
    color:rgba(255,255,255,.15);
    font-weight:900;
    font-size:42px;
    letter-spacing:4px;
}

.preview-box img{
    max-width:100%;
    max-height:100%;
    object-fit:contain;
    z-index:2;
    display:none;
    animation: zoomImg .6s ease;
}

@keyframes zoomImg{
    from{transform:scale(.85); opacity:0;}
    to{transform:none; opacity:1;}
}

/* ================= BUTTON ================= */
.btn-create{
    background:linear-gradient(135deg, var(--gold), #ffb703);
    color:#111;
    font-weight:800;
    padding:14px 45px;
    border-radius:35px;
    border:none;
    font-size:18px;
    letter-spacing:.5px;
    transition:.35s;
}

.btn-create:hover{
    transform:translateY(-3px) scale(1.08);
    box-shadow:0 0 35px rgba(255,209,102,.9);
}

/* ================= ICON ================= */
.bi{
    margin-right:6px;
}
</style>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Thêm sản phẩm</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

    <style>
        body {
            background: linear-gradient(135deg, #0f0f0f, #3a0ca3, #7209b7);
            min-height: 100vh;
            padding-bottom: 60px;
        }

        .page-title {
            text-align: center;
            color: #fff;
            font-size: 34px;
            font-weight: 800;
            margin-top: 40px;
            letter-spacing: 1px;
        }

        .form-card {
            width: 850px;
            margin: 40px auto;
            background: #ffffff;
            border-radius: 18px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.25);
            padding: 35px 45px;
            animation: fade .4s ease;
        }

        @keyframes fade {
            from { opacity: 0; transform: translateY(30px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .form-card h3 {
            text-align: center;
            font-weight: 700;
            margin-bottom: 25px;
            color: #2b2b2b;
        }

        .form-section-title {
            font-weight: 700;
            margin-top: 25px;
            margin-bottom: 15px;
            color: #3a0ca3;
        }

        .preview-box {
            width: 100%;
            height: 220px;
            border-radius: 12px;
            border: 2px dashed #bbb;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            background: #fafafa;
        }

        .preview-box img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            display: none;
        }

        .btn-create {
            background: #ffd400;
            color: #111;
            font-weight: 700;
            padding: 12px 35px;
            border-radius: 10px;
            border: none;
            font-size: 17px;
        }

        .btn-create:hover {
            background: #ffca00;
            transform: scale(1.03);
        }
    </style>
</head>

<body>

    <h1 class="page-title"><i class="bi bi-box"></i> Thêm sản phẩm mới</h1>

    <div class="form-card">

        <h3><i class="bi bi-plus-circle"></i> Thông tin sản phẩm</h3>

        <form action="/admin/xu-ly-them-san-pham" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <label class="form-section-title">📌 Thông tin cơ bản</label>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-semibold">Tên sản phẩm</label>
                    <input type="text" name="name" class="form-control" placeholder="Nhập tên..." required>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label fw-semibold">Giá (VNĐ)</label>
                    <input type="number" name="price" class="form-control" placeholder="Nhập giá..." required>
                </div>
            </div>

            <label class="form-section-title">🖼 Ảnh sản phẩm</label>
            <div class="row">
                <div class="col-md-6">
                    <label class="form-label">Upload ảnh</label>
                    <input type="file" name="img" id="upload" class="form-control mb-3">
                </div>

                <div class="col-md-6">
                    <label class="form-label">Hoặc dán link ảnh</label>
                    <input type="url" name="img_link" id="img_link" class="form-control mb-3" placeholder="https://...">
                </div>
            </div>

            <div class="preview-box">
                <img id="previewImg">
            </div>

            <label class="form-section-title">📂 Danh mục</label>
            <select name="category" class="form-select mb-3" required>
                <option value="" disabled selected>-- Chọn danh mục --</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cate->category_id); ?>"><?php echo e($cate->category_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label class="form-section-title">📝 Mô tả chi tiết</label>
            <textarea name="description" class="form-control mb-3" rows="6" placeholder="Nhập mô tả sản phẩm..."></textarea>

            <div class="text-center">
                <button type="submit" class="btn-create">
                    <i class="bi bi-upload"></i> Thêm sản phẩm
                </button>
            </div>

        </form>
    </div>

    <script>
        const upload = document.getElementById("upload");
        const linkInput = document.getElementById("img_link");
        const preview = document.getElementById("previewImg");

        upload.addEventListener("change", () => {
            const file = upload.files[0];
            if (file) {
                preview.src = URL.createObjectURL(file);
                preview.style.display = "block";
            }
        });

        linkInput.addEventListener("input", () => {
            if (linkInput.value.trim() !== "") {
                preview.src = linkInput.value;
                preview.style.display = "block";
            } else {
                preview.style.display = "none";
            }
        });
    </script>

</body>
</html>



<?php echo $__env->make('admin.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wbtm\laravel-tutorial\laravel-tutorial\resources\views/admin/product_insert_form.blade.php ENDPATH**/ ?>