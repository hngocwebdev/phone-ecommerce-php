<?php if(session('logged_in') && session('role') === 'admin'): ?>
    <?php echo $__env->make('admin.template.header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('admin.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<style>
/* ========== ANIMATION ========== */
@keyframes popIn {
    from { opacity: 0; transform: scale(.9) translateY(40px); }
    to   { opacity: 1; transform: scale(1) translateY(0); }
}

@keyframes glow {
    0% { box-shadow: 0 0 0 rgba(44,255,154,0); }
    50% { box-shadow: 0 0 40px rgba(44,255,154,.45); }
    100% { box-shadow: 0 0 0 rgba(44,255,154,0); }
}

/* ========== WRAPPER ========== */
.done-wrapper {
    max-width: 900px;
    margin: 70px auto;
    padding: 50px;
    border-radius: 32px;
    background: linear-gradient(135deg,#1b1f63,#6a11cb);
    box-shadow: 0 50px 120px rgba(0,0,0,.6);
    color: #fff;
    text-align: center;
    animation: popIn .9s ease forwards;
    position: relative;
    overflow: hidden;
}

/* ánh sáng nền chuyển động */
.done-wrapper::before {
    content: "";
    position: absolute;
    inset: -60%;
    background: radial-gradient(circle, rgba(255,255,255,.18), transparent 60%);
    animation: spin 18s linear infinite;
    pointer-events: none;
}

@keyframes spin {
    from { transform: rotate(0); }
    to   { transform: rotate(360deg); }
}

/* ========== ICON ========== */
.success-icon {
    font-size: 72px;
    margin-bottom: 12px;
    animation: glow 2s ease infinite;
}

/* ========== TITLE ========== */
.done-title {
    font-size: 38px;
    font-weight: 900;
    color: #2cff9a;
    margin-bottom: 10px;
}

/* ========== ORDER CODE ========== */
.order-code {
    font-size: 32px;
    font-weight: 900;
    letter-spacing: 1.5px;
    color: #ffd54f;
    background: rgba(0,0,0,.25);
    display: inline-block;
    padding: 12px 28px;
    border-radius: 18px;
    margin: 14px 0 28px;
}

/* ========== TOTAL ========== */
.total-box {
    background: linear-gradient(135deg,#ffd54f,#ff9800);
    color: #111;
    padding: 22px;
    border-radius: 22px;
    font-size: 20px;
    font-weight: 900;
    margin-bottom: 40px;
}

/* ========== BUTTONS ========== */
.btn-group-custom {
    display: flex;
    justify-content: center;
    gap: 20px;
    flex-wrap: wrap;
}

.btn-custom {
    padding: 14px 32px;
    font-size: 17px;
    font-weight: 800;
    border-radius: 18px;
    text-decoration: none;
    transition: .35s;
    box-shadow: 0 12px 25px rgba(0,0,0,.35);
}

.btn-history {
    background: linear-gradient(135deg,#ffd400,#ffb300);
    color: #111;
}

.btn-history:hover {
    transform: translateY(-3px);
}

.btn-shop {
    background: linear-gradient(135deg,#2cff9a,#00e676);
    color: #003;
}

.btn-shop:hover {
    transform: translateY(-3px);
}

/* ========== MOBILE ========== */
@media (max-width: 768px) {
    .done-wrapper {
        padding: 30px;
        margin: 30px 15px;
    }

    .done-title {
        font-size: 28px;
    }

    .order-code {
        font-size: 24px;
    }
}
</style>

<div class="done-wrapper">

    <div class="success-icon">🎉</div>

    <div class="done-title">
        Đặt hàng thành công!
    </div>

    <p class="fs-5 opacity-75 mb-3">
        Cảm ơn bạn đã mua sắm tại <strong>TechZone</strong>
    </p>

    <p>Mã đơn hàng của bạn</p>

    <div class="order-code">
        <?php echo e($order_code); ?>

    </div>

    <div class="total-box">
        Tổng tiền thanh toán: <?php echo e(number_format($total)); ?> đ
    </div>

    <div class="btn-group-custom">
        <a href="/lich-su-don-hang" class="btn-custom btn-history">
            📦 Lịch sử đơn hàng
        </a>

        <a href="/san-pham" class="btn-custom btn-shop">
            🛒 Tiếp tục mua sắm
        </a>
    </div>

</div>

<?php echo $__env->make('admin.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wbtm\laravel-tutorial\laravel-tutorial\resources\views/user/checkout_done.blade.php ENDPATH**/ ?>