<?php if(session('logged_in') && session('role') === 'admin'): ?>
    <?php echo $__env->make('admin.template.header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('admin.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<style>
/* ================= TOKENS ================= */
:root{
    --primary:#7c4dff;
    --secondary:#00e5ff;
    --danger:#ff4d6d;
    --success:#22c55e;
    --warning:#facc15;
    --info:#38bdf8;

    --glass-1:rgba(255,255,255,.08);
    --glass-2:rgba(255,255,255,.14);
    --border:rgba(255,255,255,.18);
    --text-soft:#cfd2ff;
}

/* ================= CONTAINER ================= */
.container{
    animation:fadeUp .8s cubic-bezier(.4,0,.2,1);
}

@keyframes fadeUp{
    from{opacity:0;transform:translateY(40px) scale(.97);}
    to{opacity:1;}
}

/* ================= TITLE ================= */
.container h2{
    font-weight:900;
    letter-spacing:1px;
    background:linear-gradient(135deg,var(--primary),var(--secondary));
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

/* ================= DELETE ALL ================= */
form .btn-danger{
    background:linear-gradient(135deg,#ff4d6d,#ff758f);
    border:none;
    font-weight:700;
    border-radius:30px;
    padding:10px 22px;
    transition:.35s;
}

form .btn-danger:hover{
    transform:translateY(-3px) scale(1.08);
    box-shadow:0 0 30px rgba(255,77,109,.8);
}

/* ================= TABLE ================= */
table.table{
    background:linear-gradient(180deg,var(--glass-2),var(--glass-1));
    backdrop-filter:blur(22px);
    border-radius:22px;
    overflow:hidden;
    border:1px solid var(--border);
    box-shadow:
        0 40px 90px rgba(0,0,0,.8),
        inset 0 0 0 1px rgba(255,255,255,.05);
}

/* ================= THEAD ================= */
.table thead{
    background:linear-gradient(135deg,var(--primary),var(--secondary));
}

.table thead th{
    color:#fff !important;
    font-weight:800;
    text-transform:uppercase;
    letter-spacing:.6px;
    border:none;
    padding:16px;
}

/* ================= CELL ================= */
.table td{
    padding:16px;
    border-bottom:1px solid rgba(255,255,255,.08);
    vertical-align:middle;
}

/* ================= ROW ================= */
.table tbody tr{
    position:relative;
    transition:.35s cubic-bezier(.4,0,.2,1);
}

.table tbody tr::after{
    pointer-events: none;
    content:"";
    position:absolute;
    inset:0;
    background:linear-gradient(
        120deg,
        transparent,
        rgba(255,255,255,.18),
        transparent
    );
    opacity:0;
    transition:.4s;
}

.table tbody tr:hover::after{
    opacity:1;
}

.table tbody tr:hover{
    background:rgba(255,255,255,.12);
    transform:scale(1.01);
}

/* ================= STATUS BADGE ================= */
td:nth-child(5){
    font-weight:700;
}

td:nth-child(5):contains("Mới"){
    color:#38bdf8;
}

td:nth-child(5):contains("Đã xác nhận"){
    color:#22c55e;
}

td:nth-child(5):contains("Đang giao"){
    color:#facc15;
}

td:nth-child(5):contains("Hoàn tất"){
    color:#4ade80;
}

td:nth-child(5):contains("Đã hủy"){
    color:#ff4d6d;
}

/* ================= ACTION BUTTON ================= */
.btn-info{
    background:linear-gradient(135deg,#38bdf8,#0ea5e9);
    border:none;
    border-radius:20px;
    font-weight:700;
    padding:6px 14px;
    transition:.3s;
}

.btn-info:hover{
    transform:scale(1.12);
    box-shadow:0 0 25px rgba(56,189,248,.8);
}

.btn-danger.btn-sm{
    background:linear-gradient(135deg,#ff4d6d,#ff758f);
    border:none;
    border-radius:20px;
    font-weight:700;
    padding:6px 14px;
    transition:.3s;
}

.btn-danger.btn-sm:hover{
    transform:scale(1.12);
    box-shadow:0 0 25px rgba(255,77,109,.8);
}
</style>


<div class="container mt-5 text-white">
    <h2 class="mb-4">Danh sách đơn hàng</h2>
    <?php if(session('role') === 'admin'): ?>
    <form action="/admin/orders/delete-all"
        method="POST"
        onsubmit="return confirm('⚠️ Bạn có chắc chắn muốn XÓA TẤT CẢ đơn hàng không?');"
        class="mb-3">
        <?php echo csrf_field(); ?>
        <!-- <button type="submit" class="btn btn-danger">
            🗑️ Xóa tất cả đơn hàng
        </button> -->
    </form>
    <?php endif; ?>


    <table class="table table-striped table-bordered text-white">
        <thead class="table-primary text-dark">
            <tr>
                <th>Mã đơn</th>
                <th>Ngày đặt</th>
                <th>Khách hàng</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
            </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->order_code); ?></td>
                <td>
                    <?php echo e(\Carbon\Carbon::parse($order->created_at)->format('d/m/Y H:i')); ?>

                </td>
                <td><?php echo e($order->fullname); ?></td>
                <td><?php echo e(number_format($order->total)); ?> đ</td>

                
                <td>
                    <?php
                        switch ($order->order_status ?? 1) {
                            case 1: echo 'Mới đặt hàng'; break;
                            case 2: echo 'Đã xác nhận'; break;
                            case 3: echo 'Đang giao hàng'; break;
                            case 4: echo 'Hoàn tất'; break;
                            case 0: echo 'Đã hủy'; break;
                            default: echo 'Không hợp lệ';
                        }
                    ?>
                </td>

                
                <td>
                    <a href="/admin/orders/<?php echo e($order->order_id); ?>"
                        class="btn btn-info btn-sm">
                        Xem
                    </a>


                    <a href="/admin/orders/delete/<?php echo e($order->order_id); ?>"
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Xóa đơn hàng này?')">
                        Xóa
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php echo $__env->make('admin.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wbtm\laravel-tutorial\laravel-tutorial\resources\views/admin/order_list.blade.php ENDPATH**/ ?>