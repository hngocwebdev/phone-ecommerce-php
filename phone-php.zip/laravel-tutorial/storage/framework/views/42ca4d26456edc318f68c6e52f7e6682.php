<?php if(session('logged_in') && session('role') === 'admin'): ?>
    <?php echo $__env->make('admin.template.header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('admin.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<style>
/* ===== RESET DARK THEME ===== */
body{
    background:#f5f6fa !important;
    color:#222;
}

/* ===== CONTAINER ===== */
.container{
    max-width:1100px;
}

/* ===== TITLE ===== */
.container h2{
    color:#1e293b !important;
    font-weight:800;
    background:none !important;
    -webkit-text-fill-color:unset !important;
}

/* ===== CARD ===== */
.card{
    background:#ffffff !important;
    border-radius:14px;
    border:1px solid #e5e7eb;
    box-shadow:0 6px 20px rgba(0,0,0,.08);
}

/* ===== CARD HEADER ===== */
.card-header{
    font-weight:700;
    padding:14px 20px;
}

/* Thông tin khách hàng */
.card-header.bg-warning{
    background:#facc15 !important;
    color:#111 !important;
}

/* Sản phẩm đã đặt */
.card-header.bg-primary{
    background:#2563eb !important;
    color:#fff !important;
}

/* ===== CARD BODY ===== */
.card-body{
    background:#fff !important;
    color:#222 !important;
    font-size:15px;
}

.card-body p{
    margin-bottom:8px;
}

/* ===== TABLE ===== */
.table{
    background:#fff;
    color:#222;
}

.table thead{
    background:#f1f5f9;
}

.table th{
    font-weight:700;
    font-size:14px;
    text-transform:uppercase;
    color:#334155;
}

.table td{
    padding:14px;
    vertical-align:middle;
}

.table tbody tr:hover{
    background:#f8fafc;
}

/* ===== TOTAL ROW ===== */
.table tfoot th{
    background:#f1f5f9;
    font-size:16px;
    font-weight:800;
}

/* ===== BACK BUTTON ===== */
.btn-secondary{
    background:#64748b;
    border:none;
    border-radius:10px;
    padding:10px 20px;
    font-weight:600;
}

.btn-secondary:hover{
    background:#475569;
}
</style>

<div class="container mt-5 text-white">
    <h2 class="mb-4">Chi tiết đơn hàng #<?php echo e($order->order_id); ?></h2>

    
    <div class="card mb-4">
        <div class="card-header bg-warning text-dark">
            Thông tin khách hàng
        </div>
        <div class="card-body text-dark">
            <p><strong>Họ tên:</strong> <?php echo e($order->fullname); ?></p>
            <p><strong>SĐT:</strong> <?php echo e($order->phone); ?></p>
            <p><strong>Địa chỉ:</strong> <?php echo e($order->address); ?></p>
            <p><strong>Ngày đặt:</strong>
                <?php echo e(\Carbon\Carbon::parse($order->created_at)->format('d/m/Y H:i')); ?>

            </p>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header bg-primary text-white">
            Sản phẩm đã đặt
        </div>

        <div class="card-body p-0">
            <table class="table table-bordered mb-0 text-dark">
                <thead class="table-light">
                    <tr>
                        <th>Tên sản phẩm</th>
                        <th>Giá</th>
                        <th>Số lượng</th>
                        <th>Thành tiền</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->product_name); ?></td>
                            <td><?php echo e(number_format($item->price)); ?> đ</td>
                            <td><?php echo e($item->qty); ?></td>
                            <td><?php echo e(number_format($item->subtotal)); ?> đ</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

                <tfoot>
                    <tr>
                        <th colspan="3" class="text-end">Tổng tiền:</th>
                        <th><?php echo e(number_format($order->total)); ?> đ</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <a href="/admin/orders" class="btn btn-secondary mt-4">
        ⬅ Quay lại danh sách đơn hàng
    </a>
</div>

<?php echo $__env->make('admin.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wbtm\laravel-tutorial\laravel-tutorial\resources\views/admin/order_detail.blade.php ENDPATH**/ ?>