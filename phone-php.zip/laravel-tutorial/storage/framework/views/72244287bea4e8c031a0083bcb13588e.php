

<style>
    body {
    margin: 0;
    padding: 80px 0;
    min-height: 100vh;
    background:
        radial-gradient(circle at top left, #7209b7, transparent 45%),
        radial-gradient(circle at bottom right, #3a0ca3, transparent 45%),
        linear-gradient(135deg, #0f0f0f, #1b1f3b);
    font-family: "Segoe UI", system-ui, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
}

/* ======================
   WRAPPER
====================== */
.login-wrapper {
    width: 100%;
    display: flex;
    justify-content: center;
    padding: 20px;
}

/* ======================
   LOGIN CARD
====================== */
.login-card {
    width: 420px;
    padding: 45px 40px;
    border-radius: 22px;
    background: rgba(255,255,255,0.14);
    backdrop-filter: blur(16px);
    border: 1.5px solid rgba(255,255,255,0.25);
    box-shadow:
        0 30px 80px rgba(0,0,0,0.45),
        inset 0 0 0 1px rgba(255,255,255,0.08);
    color: #ffffff;
    animation: fadeUp .6s ease;
}

/* ======================
   TITLE
====================== */
.login-title {
    text-align: center;
    font-size: 28px;
    font-weight: 900;
    margin-bottom: 30px;
    background: linear-gradient(135deg,#ffd400,#4be1c6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    letter-spacing: .6px;
}

/* ======================
   INPUT GROUP
====================== */
.input-group {
    margin-bottom: 20px;
}

.input-label {
    font-weight: 600;
    margin-bottom: 6px;
    color: #e7e7e7;
    display: block;
    font-size: 14px;
}

.input-box {
    width: 100%;
    padding: 13px 14px;
    border-radius: 12px;
    border: 1.5px solid rgba(255,255,255,0.25);
    background: rgba(255,255,255,0.12);
    color: #fff;
    outline: none;
    font-size: 15px;
    transition: .25s ease;
}

.input-box::placeholder {
    color: rgba(255,255,255,0.5);
}

.input-box:focus {
    border-color: #4be1c6;
    box-shadow: 0 0 0 3px rgba(75,225,198,0.35);
    background: rgba(255,255,255,0.18);
}

/* ======================
   BUTTON
====================== */
.btn-login {
    width: 100%;
    padding: 14px;
    margin-top: 10px;
    background: linear-gradient(135deg,#4be1c6,#00c9a7);
    border: none;
    border-radius: 14px;
    color: #0a1a3a;
    font-weight: 900;
    font-size: 17px;
    cursor: pointer;
    transition: .3s ease;
    box-shadow: 0 15px 35px rgba(0,201,167,0.45);
}

.btn-login:hover {
    transform: translateY(-3px);
    box-shadow: 0 22px 45px rgba(0,201,167,0.6);
    color: #ffffff;
}

/* ======================
   MESSAGE
====================== */
.error-box,
.success-box {
    padding: 14px;
    border-radius: 10px;
    margin-bottom: 18px;
    font-size: 14px;
}

.error-box {
    background: rgba(255,0,0,0.18);
    border-left: 4px solid #ff4d4f;
}

.success-box {
    background: rgba(0,255,150,0.18);
    border-left: 4px solid #2ecc71;
}

/* ======================
   SWITCH MODE
====================== */
.signup {
    text-align: center;
    margin-top: 22px;
    font-size: 14px;
    color: #ddd;
}

.signup a {
    color: #4be1c6;
    font-weight: 700;
    text-decoration: none;
    transition: .25s;
}

.signup a:hover {
    text-decoration: underline;
}

/* ======================
   ANIMATION
====================== */
@keyframes fadeUp {
    from {
        opacity: 0;
        transform: translateY(40px) scale(.96);
    }
    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}

/* ======================
   MOBILE
====================== */
@media (max-width: 480px) {
    .login-card {
        padding: 35px 28px;
    }

    .login-title {
        font-size: 24px;
    }
}

</style>

<div class="login-wrapper">
    <div class="login-card">

        
        <div class="login-title">
            <?php echo e($mode === 'register' ? 'ĐĂNG KÝ TÀI KHOẢN' : 'ĐĂNG NHẬP HỆ THỐNG'); ?>

        </div>

        
        <?php if(session('error')): ?>
            <div class="error-box"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="success-box"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        
        <form
            action="<?php echo e($mode === 'register' ? url('/register') : url('/admin/xu-ly-login')); ?>"
            method="POST"
        >
            <?php echo csrf_field(); ?>

            <div class="input-group">
                <label class="input-label">Tên đăng nhập</label>
                <input type="text" name="username" class="input-box" required>
            </div>

            <div class="input-group">
                <label class="input-label">Mật khẩu</label>
                <input type="password" name="password" class="input-box" required>
            </div>

            
            <?php if($mode === 'register'): ?>
                <div class="input-group">
                    <label class="input-label">Họ tên</label>
                    <input type="text" name="fullname" class="input-box" required>
                </div>

                <div class="input-group">
                    <label class="input-label">Địa chỉ</label>
                    <input type="text" name="address" class="input-box" required>
                </div>
            <?php endif; ?>

            <button class="btn-login">
                <?php echo e($mode === 'register' ? 'Đăng ký' : 'Đăng nhập'); ?>

            </button>
        </form>

        
        <div class="signup">
            <?php if($mode === 'register'): ?>
                Đã có tài khoản?
                <a href="<?php echo e(url('/admin/login')); ?>">Đăng nhập</a>
            <?php else: ?>
                Chưa có tài khoản?
                <a href="<?php echo e(url('/register')); ?>">Tạo tài khoản</a>
            <?php endif; ?>
        </div>

    </div>
</div>
<?php /**PATH C:\wbtm\laravel-tutorial\23662010_NguyenThiHongNgoc\laravel-tutorial\resources\views/admin/user_login.blade.php ENDPATH**/ ?>