<?php if(session('logged_in') && session('role') === 'admin'): ?>
    <?php echo $__env->make('admin.template.header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('admin.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php
    $discountPercent = 20;
    $salePrice = $product->product_price * (100 - $discountPercent) / 100;
?>

<style>
/* ================= WRAPPER ================= */
.product-detail-wrapper {
    display: grid;
    grid-template-columns: 1fr 1.2fr;
    gap: 50px;
    background: #ffffff;
    border-radius: 30px;
    padding: 45px;
    box-shadow: 0 35px 90px rgba(0,0,0,0.35);
}

/* ================= IMAGE ================= */
.product-image-box {
    background: #f6f6f6;
    border-radius: 24px;
    padding: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.product-image-box img {
    max-width: 100%;
    max-height: 430px;
    object-fit: contain;
    transition: transform .4s ease;
}

.product-image-box:hover img {
    transform: scale(1.08);
}

/* ================= INFO ================= */
.product-info-box {
    color: #111;
}

.product-title {
    font-size: 36px;
    font-weight: 900;
    margin-bottom: 20px;
}

/* ================= PRICE ================= */
.price-box {
    margin-bottom: 24px;
}

.old-price {
    color: #9a9a9a;
    text-decoration: line-through;
    font-size: 18px;
}

.discount-badge {
    background: linear-gradient(135deg,#ff9800,#ff3b30);
    color: #fff;
    font-size: 13px;
    font-weight: 800;
    padding: 6px 14px;
    border-radius: 999px;
    margin-left: 10px;
}

.sale-price {
    font-size: 40px;
    font-weight: 900;
    color: #ff3b30;
    margin-top: 8px;
}

/* ================= DESC ================= */
.product-desc {
    font-size: 15.5px;
    line-height: 1.75;
    color: #444;
    margin-bottom: 35px;
}

/* ================= QTY ================= */
.qty-label {
    font-weight: 700;
    margin-bottom: 10px;
}

.qty-control {
    display: flex;
    align-items: center;
    gap: 14px;
    margin-bottom: 35px;
}

.qty-control button {
    width: 46px;
    height: 46px;
    border-radius: 14px;
    border: none;
    background: #eee;
    font-size: 22px;
    font-weight: bold;
    cursor: pointer;
    transition: .25s;
}

.qty-control button:hover {
    background: #ffd400;
}

.qty-control input {
    width: 80px;
    height: 46px;
    text-align: center;
    font-size: 18px;
    font-weight: 800;
    border-radius: 14px;
    border: 1px solid #ddd;
}

/* ================= BUTTON ================= */
.add-cart-btn {
    width: 100%;
    padding: 18px;
    font-size: 19px;
    font-weight: 900;
    border-radius: 20px;
    border: none;
    background: linear-gradient(135deg,#ffd400,#ffb300);
    cursor: pointer;
    transition: .35s;
}

.add-cart-btn:hover {
    transform: translateY(-4px);
    box-shadow: 0 22px 45px rgba(0,0,0,.3);
}

/* ================= MOBILE ================= */
@media (max-width: 768px) {
    .product-detail-wrapper {
        grid-template-columns: 1fr;
        padding: 25px;
    }
}
</style>

<div class="container my-5">
    <div class="product-detail-wrapper">

        
        <div class="product-image-box">
            <img src="<?php echo e($product->product_img); ?>" alt="<?php echo e($product->product_name); ?>">
        </div>

        
        <div class="product-info-box">
            <h1 class="product-title"><?php echo e($product->product_name); ?></h1>

            <div class="price-box">
                <span class="old-price"><?php echo e(number_format($product->product_price)); ?> đ</span>
                <span class="discount-badge">-<?php echo e($discountPercent); ?>%</span>

                <div class="sale-price">
                    <?php echo e(number_format($salePrice)); ?> đ
                </div>
            </div>

            <p class="product-desc">
                <?php echo e($product->product_description); ?>

            </p>

            <div class="qty-label">Số lượng</div>
            <div class="qty-control">
                <button type="button" onclick="changeQty(-1)">−</button>
                <input id="qty" type="number" value="1" readonly>
                <button type="button" onclick="changeQty(1)">+</button>
            </div>

            <form action="/add-to-cart/<?php echo e($product->product_id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="qty" id="qty-hidden" value="1">

                <button type="submit" class="add-cart-btn">
                    🛒 Thêm vào giỏ hàng
                </button>
            </form>
        </div>

    </div>
</div>

<script>
function changeQty(step) {
    const input = document.getElementById('qty');
    const hidden = document.getElementById('qty-hidden');

    let value = parseInt(input.value) || 1;
    value += step;
    if (value < 1) value = 1;

    input.value = value;
    hidden.value = value;
}
</script>

<?php echo $__env->make('admin.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\wbtm\laravel-tutorial\laravel-tutorial\resources\views/user/product_detail.blade.php ENDPATH**/ ?>