<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class CheckAdmin
{
    public function handle(Request $request, Closure $next)
    {
        // Chưa đăng nhập
        if (!session('logged_in')) {
            return redirect('/admin/login')
                ->with('error', 'Vui lòng đăng nhập');
        }

        // Đã login nhưng không phải admin
        if (session('role') !== 'admin') {
            return redirect('/')
                ->with('error', 'Bạn không có quyền truy cập trang quản trị');
        }

        return $next($request);
    }

}
