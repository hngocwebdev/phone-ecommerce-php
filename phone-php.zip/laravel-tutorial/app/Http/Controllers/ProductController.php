<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProductModel;
use Illuminate\Support\Facades\DB;
use App\Models\CategoryModel;

class ProductController extends Controller
{
    /* ============================
       FORM THÊM SẢN PHẨM
       ============================ */
    public function insert_form() {
        $categories = CategoryModel::all();
        return view('admin/product_insert_form', ['categories' => $categories]);
    }

    /* ============================
       XỬ LÝ THÊM SẢN PHẨM
       ============================ */
    public function action_insert(Request $request)
    {
        $name        = $request->input('name');
        $price       = $request->input('price');
        $description = $request->input('description') ?? ''; 
        $category    = $request->input('category');

        // Xử lý ảnh
        if ($request->hasFile('img')) {
            $file = $request->file('img');
            $file->move('img', $file->getClientOriginalName());
            $img_name = 'img/' . $file->getClientOriginalName();
        } elseif ($request->filled('img_link')) {
            $img_name = $request->input('img_link');
        } else {
            $img_name = 'img/default.png';
        }

        ProductModel::insert([
            'product_name'        => $name,
            'product_img'         => $img_name,
            'product_price'       => $price,
            'product_category'    => $category,
            'product_description' => $description,
        ]);

        return redirect()->to('admin/danh-sach-san-pham');
    }

    /* ============================
       XỬ LÝ CẬP NHẬT
       ============================ */
    public function action_update(Request $request)
    {
        $id          = $request->input('id');
        $name        = $request->input('name');
        $price       = $request->input('price');
        $category    = $request->input('category');
        $description = $request->input('description') ?? '';

        // Xử lý ảnh
        if ($request->hasFile('img')) {
            $file = $request->file('img');
            $file->move('img', $file->getClientOriginalName());
            $img_name = 'img/' . $file->getClientOriginalName();
        } elseif ($request->filled('img_link')) {
            $img_name = $request->input('img_link');
        } else {
            $img_name = $request->input('img_old');
        }

        ProductModel::where('product_id', $id)->update([
            'product_name'        => $name,
            'product_img'         => $img_name,
            'product_price'       => $price,
            'product_category'    => $category,
            'product_description' => $description,
        ]);

        return redirect()->to('admin/danh-sach-san-pham');
    }

    /* ============================
       DANH SÁCH SẢN PHẨM
       ============================ */
    public function get_all()
    {
        $products = ProductModel::join('category', 'product_category', '=', 'category_id')->get();
        return view('admin/product_list', ['products' => $products]);
    }

    public function user_list()
    {
        $products = ProductModel::join('category', 'product_category', '=', 'category_id')
            ->where('is_active', 1)
            ->get();

        return view('user/product_list', ['products' => $products]);
    }


    public function admin_product_list()
    {
        $products = ProductModel::join('category', 'product_category', '=', 'category_id')->get();
        return view('admin.product_list', compact('products'));
    }


    /* ============================
       XÓA SẢN PHẨM
       ============================ */
    public function del($id)
    {
        // ẨN sản phẩm thay vì xóa khỏi DB
        DB::table('product')
            ->where('product_id', $id)
            ->update(['is_active' => 0]);

        return redirect()->back()->with('success', 'Đã ẩn sản phẩm khỏi website!');
    }


    /* ============================
       FORM SỬA
       ============================ */
    public function show($id)
    {
        $products = ProductModel::where('product_id', $id)->first();
        $categories = CategoryModel::all();

        return view('admin/product_info_form', [
            'product'    => $products,
            'categories' => $categories,
        ]);
    }

    /* ============================
       CHI TIẾT SẢN PHẨM
       ============================ */
    public function detail($id)
    {
        $product = ProductModel::join('category', 'product_category', '=', 'category_id')
            ->where('product_id', $id)
            ->where('is_active', 1)
            ->first();

        if (!$product) {
            abort(404, 'Sản phẩm không tồn tại hoặc đã bị ẩn');
        }


        return view('user.product_detail', compact('product'));
    }

    /* ============================
       TRANG CHỦ + TÌM KIẾM + LỌC DANH MỤC
       ============================ */
    public function homepage(Request $request)
    {
        // ⭐ CHỈ LẤY SẢN PHẨM ĐANG HOẠT ĐỘNG
        $query = ProductModel::where('is_active', 1);

        $search   = $request->input('search');
        $category = $request->input('category');

        $categories = CategoryModel::all();

        if ($search) {
            $query->where('product_name', 'LIKE', '%' . $search . '%');
        }

        if ($category) {
            $query->where('product_category', $category);
        }

        // Không tìm gì → hiển thị SP mới nhất
        if (!$search && !$category) {
            $query->orderBy('product_id', 'desc')->limit(8);
        }

        $products = $query->get();

        return view('welcome', compact('products', 'categories', 'search', 'category'));
    }

    public function search(Request $request)
    {
        $search = $request->input('key');

        $products = ProductModel::where('is_active', 1)
            ->where('product_name', 'LIKE', '%' . $search . '%')
            ->limit(20)
            ->get();


        $categories = CategoryModel::all();

        return view('welcome', [
            'products' => $products,
            'categories' => $categories,
            'search' => $search,
            'category' => null
        ]);
    }

    public function restore($id)
    {
        DB::table('product')
            ->where('product_id', $id)
            ->update(['is_active' => 1]);

        return redirect()->back()->with('success', 'Đã khôi phục sản phẩm!');
    }


}

