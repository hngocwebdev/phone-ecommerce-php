<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Users;


class UserController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | ADMIN - QUẢN LÝ NGƯỜI DÙNG
    |--------------------------------------------------------------------------
    */

    // Form thêm user (ADMIN)
    public function insert_form()
    {
        return view('admin.user_insert_form');
    }

    // Xử lý thêm user (ADMIN)
    public function action_insert(Request $request)
    {
        // Check trùng username
        if (Users::where('user_username', $request->username)->exists()) {
            return back()->with('error', 'Tài khoản đã tồn tại');
        }

        Users::insert([
            'user_username' => $request->username,
            'user_password' => Hash::make($request->password), // 🔐 HASH
            'user_fullname' => $request->fullname,
            'user_address'  => $request->address,
            'role'          => 'user'
        ]);

        return redirect('/admin/danh-sach-nguoi-dung')
            ->with('success', 'Thêm người dùng thành công');
    }

    // Cập nhật user (ADMIN)
    public function action_update(Request $request)
    {
        Users::where('user_id', $request->id)->update([
            'user_username' => $request->username,
            'user_fullname' => $request->fullname,
            'user_address'  => $request->address
        ]);

        return redirect('/admin/danh-sach-nguoi-dung')
            ->with('success', 'Cập nhật thành công');
    }

    // Danh sách user (ADMIN)
    public function get_all()
    {
        $users = Users::all();
        return view('admin.user_list', compact('users'));
    }

    // Xóa user (ADMIN)
    public function del($id)
    {
        Users::where('user_id', $id)->delete();
        return redirect('/admin/danh-sach-nguoi-dung')
            ->with('success', 'Đã xóa người dùng');
    }

    // Form sửa user (ADMIN)
    public function show($id)
    {
        $users = Users::where('user_id', $id)->get();
        return view('admin.user_info_form', compact('users'));
    }

    /*
    |--------------------------------------------------------------------------
    | LOGIN
    |--------------------------------------------------------------------------
    */

    // Form đăng nhập
    public function login_form()
    {
        return view('admin.user_login', [
            'mode' => 'login'
        ]);
    }

    // Xử lý đăng nhập
    public function action_login(Request $request)
    {
        if (!$request->username || !$request->password) {
            return back()->with('error', 'Vui lòng nhập đầy đủ thông tin');
        }

        $user = Users::where('user_username', $request->username)->first();

        // ✅ So mật khẩu thường (vì Hash đang lỗi package)
        if (!$user || $request->password !== $user->user_password) {
            return back()->with('error', 'Sai tên đăng nhập hoặc mật khẩu');
        }

        session([
            'logged_in' => true,
            'user_id'   => $user->user_id,
            'username'  => $user->user_username,
            'fullname'  => $user->user_fullname,
            'role'      => $user->role,
        ]);

        return ($user->role === 'admin')
            ? redirect('/admin/danh-sach-nguoi-dung')
            : redirect('/');
    }




    /*
    |--------------------------------------------------------------------------
    | USER - ĐĂNG KÝ (DÙNG CHUNG VIEW LOGIN)
    |--------------------------------------------------------------------------
    */

    // Form đăng ký
    public function registerForm()
    {
        return view('admin.user_login', [
            'mode' => 'register'
        ]);
    }

    // Xử lý đăng ký
    public function register(Request $request)
    {
        if (!$request->username || !$request->password || !$request->fullname || !$request->address) {
            return back()->with('error', 'Vui lòng nhập đủ thông tin');
        }

        if (Users::where('user_username', $request->username)->exists()) {
            return back()->with('error', 'Tên đăng nhập đã tồn tại');
        }

        Users::insert([
            'user_username' => $request->username,
            'user_password' => $request->password, // ✅ lưu plain
            'user_fullname' => $request->fullname,
            'user_address'  => $request->address,
            'role'          => 'user'
        ]);

        return redirect('/admin/login')->with('success', 'Đăng ký thành công! Vui lòng đăng nhập');
    }
    private function getCartId()
    {
        $userId = session('user_id');

        if (!$userId) {
            abort(403, 'Chưa đăng nhập');
        }

        $cart = DB::table('carts')->where('user_id', $userId)->first();

        if (!$cart) {
            return DB::table('carts')->insertGetId([
                'user_id'    => $userId,
                'created_at' => now()
            ]);
        }

        return $cart->cart_id;
    }


}
