<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class OrderController extends Controller
{
    public function adminDeleteAllOrders()
    {
        // XÓA CHI TIẾT ĐƠN HÀNG TRƯỚC (FK)
        DB::table('order_items')->delete();

        // XÓA ĐƠN HÀNG
        DB::table('orders')->delete();

        return redirect('/admin/orders')->with('success', 'Đã xóa tất cả đơn hàng');
    }
     // =============================
    // FORM CHECKOUT
    // =============================
    public function form()
    {
        if (!session('logged_in')) {
            return redirect('/admin/login');
        }

        // ✅ 1️⃣ ƯU TIÊN MUA NGAY
        if (session()->has('buy_now')) {
            $cart = collect(session('buy_now'));

            return view('user.checkout_form', compact('cart'));
        }

        // ✅ 2️⃣ GIỎ HÀNG MYSQL (LOGIC CŨ)
        $cartId = $this->getCartId();

        $cart = DB::table('cart_items')
            ->where('cart_id', $cartId)
            ->get();

        if ($cart->count() === 0) {
            return redirect('/cart')->with('error', 'Giỏ hàng trống');
        }

        return view('user.checkout_form', compact('cart'));
    }


    // =============================
    // CONFIRM
    // =============================
    public function confirm(Request $request)
    {
        if (!$request->fullname || !$request->phone || !$request->address) {
            return back()->with('error', 'Vui lòng nhập đầy đủ thông tin');
        }

        $data = [
            'fullname' => $request->fullname,
            'phone'    => $request->phone,
            'address'  => $request->address,
        ];

        $cartId = $this->getCartId();

        $cart = DB::table('cart_items')
            ->where('cart_id', $cartId)
            ->get();

        if ($cart->count() === 0) {
            return redirect('/cart')->with('error', 'Giỏ hàng trống');
        }

        return view('user.checkout_confirm', compact('cart', 'data'));
    }

    // =============================
    // DONE – CREATE ORDER (MYSQL)
    // =============================
    public function done(Request $request)
    {
        if (!session('logged_in')) {
            return redirect('/login');
        }

        $cartIds = $request->cart_ids;

        if (!$cartIds || count($cartIds) === 0) {
            return redirect('/cart')->with('error', 'Giỏ hàng trống');
        }

        // Lấy cart items
        $cart = DB::table('cart_items')
            ->whereIn('cart_item_id', $cartIds)
            ->get();

        if ($cart->isEmpty()) {
            return redirect('/cart')->with('error', 'Không tìm thấy sản phẩm');
        }

        // Tính tổng
        $total = 0;
        foreach ($cart as $item) {
            $total += $item->price * $item->qty;
        }

        // ✅ TẠO MÃ ĐƠN HÀNG
        $orderCode = 'TZ-' . date('Ymd-His');

        // ✅ TẠO ĐƠN HÀNG
        $orderId = DB::table('orders')->insertGetId([
            'fullname'   => $request->fullname,
            'phone'      => $request->phone,
            'address'    => $request->address,
            'total'      => $total,
            'user_id'    => session('user_id'),
            'order_code' => $orderCode,
        ]);

        // ✅ LƯU CHI TIẾT ĐƠN HÀNG
        foreach ($cart as $item) {
            DB::table('order_items')->insert([
                'order_id'     => $orderId,
                'product_id'   => $item->product_id,
                'product_name' => $item->product_name,
                'price'        => $item->price,
                'qty'          => $item->qty,
                'subtotal'     => $item->price * $item->qty,
            ]);
        }

        // ✅ XÓA CART
        DB::table('cart_items')
            ->whereIn('cart_item_id', $cartIds)
            ->delete();

        // ✅ TRẢ VỀ TRANG DONE (KHÔNG REDIRECT)
        return view('user.checkout_done', [
            'order_id'   => $orderId,
            'order_code' => $orderCode,
            'total'      => $total,
        ]);
    }





    // =============================
    // GET CART ID
    // =============================
    private function getCartId()
    {
        $userId = session('user_id');

        $cart = DB::table('carts')->where('user_id', $userId)->first();

        if (!$cart) {
            return DB::table('carts')->insertGetId([
                'user_id'    => $userId,
                'created_at' => now()
            ]);
        }

        return $cart->cart_id;
    }


    // ===============================
    // USER: LỊCH SỬ ĐƠN HÀNG
    // ===============================
    public function userOrderHistory()
    {
        if (!session('logged_in')) {
            return redirect('/admin/login')
                ->with('error', 'Bạn cần đăng nhập để xem lịch sử đơn hàng!');
        }

        $orders = DB::table('orders')
            ->where('user_id', session('user_id'))
            ->orderBy('order_id', 'desc')
            ->get();

        return view('user.order_list', compact('orders'));
    }

    // ===============================
    // ADMIN: DANH SÁCH ĐƠN HÀNG
    // ===============================
    public function adminOrderList()
    {
        if (!session('logged_in') || session('role') !== 'admin') {
            return redirect('/')->with('error', 'Không có quyền truy cập!');
        }

        $orders = DB::table('orders')
            ->orderBy('order_id', 'desc')
            ->get();

        return view('admin.order_list', compact('orders'));
    }

    // ===============================
    // ADMIN: CHI TIẾT ĐƠN HÀNG
    // ===============================
    public function adminOrderDetail($order_id)
    {
        if (!session('logged_in') || session('role') !== 'admin') {
            return redirect('/')->with('error', 'Không có quyền truy cập!');
        }

        $order = DB::table('orders')
            ->where('order_id', $order_id)
            ->first();

        if (!$order) {
            return redirect('/admin/orders')
                ->with('error', 'Đơn hàng không tồn tại!');
        }

        $items = DB::table('order_items')
            ->where('order_id', $order_id)
            ->get();

        return view('admin.order_detail', compact('order', 'items'));
    }
    // ===============================
// ADMIN: XÓA ĐƠN HÀNG
// ===============================
    public function adminOrderDelete($id)
    {
        // Kiểm tra đơn tồn tại
        $order = DB::table('orders')->where('order_id', $id)->first();

        if (!$order) {
            return redirect('/admin/orders')
                ->with('error', 'Đơn hàng không tồn tại');
        }

        // XÓA CHI TIẾT ĐƠN TRƯỚC (FK)
        DB::table('order_items')->where('order_id', $id)->delete();

        // XÓA ĐƠN
        DB::table('orders')->where('order_id', $id)->delete();

        return redirect('/admin/orders')
            ->with('success', 'Đã xóa đơn hàng');
    }

    // 
    // MUA NGAY (BUY NOW)

    public function buyNow(Request $request, $productId)
    {
        if (!session('logged_in')) {
            return redirect('/admin/login')
                ->with('error', 'Vui lòng đăng nhập để mua hàng');
        }

        $qty = max(1, (int)$request->qty);

        $product = DB::table('products')
            ->where('product_id', $productId)
            ->where('is_active', 1)
            ->first();

        if (!$product) {
            return redirect('/')->with('error', 'Sản phẩm không tồn tại');
        }

        // LƯU VÀO SESSION ĐỂ CHECKOUT DÙNG
        session([
            'buy_now' => [
                [
                    'product_id'   => $product->product_id,
                    'product_name' => $product->product_name,
                    'price'        => $product->product_price,
                    'qty'          => $qty,
                    'img'          => $product->product_img,
                ]
            ]
        ]);

        return redirect('/checkout');
    }


}
