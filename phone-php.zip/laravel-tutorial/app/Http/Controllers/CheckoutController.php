<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CheckoutController extends Controller
{
    // 🔹 Trang nhập thông tin giao hàng (LẤY MYSQL)
    public function form()
    {
        if (!session('logged_in')) {
            return redirect('/login');
        }

        // Lấy đơn hàng gần nhất để autofill
        $lastOrder = DB::table('orders')
            ->where('user_id', session('user_id'))
            ->orderBy('created_at', 'desc')
            ->first();

        return view('user.checkout_form', [
            'lastOrder' => $lastOrder
        ]);
    }

    // 🔹 Nhận form & tạo đơn hàng
    public function confirm(Request $request)
    {
        // Lấy cart
        $cart = DB::table('carts')
            ->where('user_id', session('user_id'))
            ->first();

        if (!$cart) {
            return redirect('/cart')->with('error', 'Giỏ hàng trống');
        }

        $cartItems = DB::table('cart_items')
            ->where('cart_id', $cart->cart_id)
            ->get();

        if ($cartItems->isEmpty()) {
            return redirect('/cart')->with('error', 'Giỏ hàng trống');
        }

        // Tính tổng tiền
        $total = 0;
        foreach ($cartItems as $item) {
            $total += $item->price * $item->qty;
        }

        // ✅ CHỈ render trang confirm
        return view('user.checkout_confirm', [
            'fullname'  => $request->fullname,
            'phone'     => $request->phone,
            'address'   => $request->address,
            'cartItems' => $cartItems,
            'total'     => $total,
        ]);
    }

    public function done(Request $request)
    {
        if (!session('logged_in')) {
            return redirect('/login');
        }

        // Lấy cart
        $cart = DB::table('carts')
            ->where('user_id', session('user_id'))
            ->first();

        if (!$cart) {
            return redirect('/cart');
        }

        $cartItems = DB::table('cart_items')
            ->where('cart_id', $cart->cart_id)
            ->get();

        // Tính tổng tiền
        $total = 0;
        foreach ($cartItems as $item) {
            $total += $item->price * $item->qty;
        }

        // Tạo mã đơn hàng
        $orderCode = 'TZ-' . date('Ymd-His');

        // Lưu orders
        $orderId = DB::table('orders')->insertGetId([
            'user_id'    => session('user_id'),
            'fullname'   => $request->fullname,
            'phone'      => $request->phone,
            'address'    => $request->address,
            'total'      => $total,
            'order_code' => $orderCode,
            'status'     => 'pending',
            'created_at' => now(),
        ]);

        // Lưu order_items
        foreach ($cartItems as $item) {
            DB::table('order_items')->insert([
                'order_id'     => $orderId,
                'product_id'   => $item->product_id,
                'product_name' => $item->product_name,
                'price'        => $item->price,
                'qty'          => $item->qty,
                'subtotal'     => $item->price * $item->qty,
            ]);
        }

        // Xóa cart_items
        DB::table('cart_items')
            ->where('cart_id', $cart->cart_id)
            ->delete();

        // 👉 TRUYỀN DỮ LIỆU SANG VIEW DONE
        return view('user.checkout_done', [
            'order_code' => $orderCode,
            'total'      => $total,
        ]);
    }



}
