<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CartController extends Controller
{
    private function getCartId()
    {
        $userId = session('user_id');

        $cart = DB::table('carts')->where('user_id', $userId)->first();

        if (!$cart) {
            return DB::table('carts')->insertGetId([
                'user_id'    => $userId,
                'created_at' => now()
            ]);
        }

        return $cart->cart_id;
    }

    public function add(Request $request, $id)
    {
        if (!session('logged_in')) {
            return redirect('/admin/login')
                ->with('error', 'Vui lòng đăng nhập');
        }

        if (session('role') === 'admin') {
            return back()->with('error', 'Admin không thể mua hàng');
        }

        $qty = max(1, (int)$request->qty);

        // ✅ BẢNG product (KHÔNG PHẢI products)
        $product = DB::table('product')
            ->where('product_id', $id)
            ->where('is_active', 1)
            ->first();

        if (!$product) {
            return back()->with('error', 'Sản phẩm không tồn tại');
        }

        $cartId = $this->getCartId();

        $item = DB::table('cart_items')
            ->where('cart_id', $cartId)
            ->where('product_id', $id)
            ->first();

        if ($item) {
            DB::table('cart_items')
                ->where('cart_item_id', $item->cart_item_id)
                ->increment('qty', $qty);
        } else {
            DB::table('cart_items')->insert([
                'cart_id'      => $cartId,
                'product_id'   => $product->product_id,
                'product_name' => $product->product_name,
                'price'        => $product->product_price,
                'qty'          => $qty,
                'img'          => $product->product_img,
                'created_at'   => now()
            ]);
        }

        return redirect('/cart')->with('success', 'Đã thêm vào giỏ hàng');
    }

    public function view()
    {
        if (!session('logged_in')) {
            return redirect('/admin/login');
        }

        if (session('role') === 'admin') {
            return redirect('/')->with('error', 'Admin không có giỏ hàng');
        }

        $cartId = $this->getCartId();

        $cart = DB::table('cart_items')
            ->where('cart_id', $cartId)
            ->get();

        return view('user.cart', compact('cart'));
    }

    public function update(Request $request)
    {
        $cartId = $this->getCartId();

        foreach ($request->qty as $cartItemId => $qty) {
            DB::table('cart_items')
                ->where('cart_item_id', $cartItemId)
                ->where('cart_id', $cartId)
                ->update([
                    'qty' => max(1, (int)$qty)
                ]);
        }

        return back()->with('success', 'Đã cập nhật giỏ hàng');
    }

    public function remove($cartItemId)
    {
        $cartId = $this->getCartId();

        DB::table('cart_items')
            ->where('cart_item_id', $cartItemId)
            ->where('cart_id', $cartId)
            ->delete();

        return back()->with('success', 'Đã xóa sản phẩm');
    }

    //
    public function buyNow(Request $request, $id)
    {
        if (!session('logged_in')) {
            return redirect('/admin/login');
        }

        $qty = $request->qty ?? 1;

        $cartId = $this->getCartId();

        // Lấy sản phẩm
        $product = DB::table('products')
            ->where('product_id', $id)
            ->first();

        if (!$product) {
            return redirect('/')->with('error', 'Sản phẩm không tồn tại');
        }

        // Xóa cart cũ (nếu muốn mua ngay 1 SP)
        DB::table('cart_items')->where('cart_id', $cartId)->delete();

        // Thêm sản phẩm vào cart
        DB::table('cart_items')->insert([
            'cart_id'       => $cartId,
            'product_id'    => $product->product_id,
            'product_name'  => $product->product_name,
            'price'         => $product->product_price,
            'qty'           => $qty,
            'img'           => $product->product_img,
            'created_at'    => now(),
        ]);

        // 👉 Chuyển sang checkout
        return redirect('/checkout');
    }

    // CẬP NHẬT GIỎ HÀNG BẰNG AJAX
    public function updateAjax(Request $request)
    {
        $cartItemId = $request->cart_item_id;
        $qty = max(1, (int)$request->qty);

        DB::table('cart_items')
            ->where('cart_item_id', $cartItemId)
            ->update(['qty' => $qty]);

        // Lấy lại tổng số lượng cho badge
        $cart = DB::table('carts')
            ->where('user_id', session('user_id'))
            ->first();

        $cartCount = DB::table('cart_items')
            ->where('cart_id', $cart->cart_id)
            ->sum('qty');

        return response()->json([
            'success' => true,
            'cartCount' => $cartCount
        ]);
    }


}
